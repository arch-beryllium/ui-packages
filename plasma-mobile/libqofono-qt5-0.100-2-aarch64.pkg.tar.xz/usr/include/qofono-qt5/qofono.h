/****************************************************************************
**
** Copyright (C) 2013-2014 Jolla Ltd.
** Contact: lorn.potter@jollamobile.com
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 2.1 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU Lesser General Public License version 2.1 requirements
** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
****************************************************************************/

#ifndef QOFONO_H
#define QOFONO_H

#include "qofono_global.h"

class QOFONOSHARED_EXPORT QOfono
{
public:
    QOfono();

    static QString mobileCountryCodeToAlpha2CountryCode(int mcc);
    static void registerObjectPathPropertiesType();
};

#endif // QOFONO_H
