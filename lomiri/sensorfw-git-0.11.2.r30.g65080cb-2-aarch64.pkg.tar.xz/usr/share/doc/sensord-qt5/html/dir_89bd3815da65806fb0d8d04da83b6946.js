var dir_89bd3815da65806fb0d8d04da83b6946 =
[
    [ "alsadaptor-sysfs.h", "alsadaptor-sysfs_8h.html", [
      [ "ALSAdaptorSysfs", "classALSAdaptorSysfs.html", "classALSAdaptorSysfs" ]
    ] ],
    [ "alsadaptor-sysfsplugin.h", "alsadaptor-sysfsplugin_8h.html", [
      [ "ALSAdaptorSysfsPlugin", "classALSAdaptorSysfsPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2alsadaptor-sysfs_2moc__predefs_8h.html", "adaptors_2alsadaptor-sysfs_2moc__predefs_8h" ]
];