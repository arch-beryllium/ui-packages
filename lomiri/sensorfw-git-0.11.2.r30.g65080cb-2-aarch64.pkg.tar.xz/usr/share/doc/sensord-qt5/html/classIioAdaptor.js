var classIioAdaptor =
[
    [ "IioAdaptor", "classIioAdaptor.html#ac413efb6eaa93fff41bf1de5410aa6a4", null ],
    [ "~IioAdaptor", "classIioAdaptor.html#a515738276a7e65b9757e235b86bf8b6a", null ],
    [ "setInterval", "classIioAdaptor.html#abcdc2581d08ee44d1f5a6f69641262c1", null ],
    [ "startSensor", "classIioAdaptor.html#acda47cda68d8896468075bf225230445", null ],
    [ "stopSensor", "classIioAdaptor.html#a43b442faaa4fa75b9d65b209ffc5415d", null ]
];