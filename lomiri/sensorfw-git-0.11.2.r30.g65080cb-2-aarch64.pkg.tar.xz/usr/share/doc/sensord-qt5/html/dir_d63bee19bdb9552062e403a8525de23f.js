var dir_d63bee19bdb9552062e403a8525de23f =
[
    [ "moc_predefs.h", "sensors_2temperaturesensor_2moc__predefs_8h.html", "sensors_2temperaturesensor_2moc__predefs_8h" ],
    [ "temperatureplugin.h", "temperatureplugin_8h.html", [
      [ "TemperaturePlugin", "classTemperaturePlugin.html", null ]
    ] ],
    [ "temperaturesensor.h", "temperaturesensor_8h.html", [
      [ "TemperatureSensorChannel", "classTemperatureSensorChannel.html", "classTemperatureSensorChannel" ]
    ] ],
    [ "temperaturesensor_a.h", "temperaturesensor__a_8h.html", [
      [ "TemperatureSensorChannelAdaptor", "classTemperatureSensorChannelAdaptor.html", "classTemperatureSensorChannelAdaptor" ]
    ] ]
];