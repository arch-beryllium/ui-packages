var dir_8a7d63aae1a15aa0e84cf6796b81b5c3 =
[
    [ "hybrisorientationadaptor.h", "hybrisorientationadaptor_8h.html", [
      [ "HybrisOrientationAdaptor", "classHybrisOrientationAdaptor.html", "classHybrisOrientationAdaptor" ]
    ] ],
    [ "hybrisorientationadaptorplugin.h", "hybrisorientationadaptorplugin_8h.html", [
      [ "HybrisOrientationAdaptorPlugin", "classHybrisOrientationAdaptorPlugin.html", null ]
    ] ]
];