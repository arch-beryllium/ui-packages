var dir_90ada3ab86102bf555a69c6d95da4bfe =
[
    [ "magnetometeradaptor.h", "magnetometeradaptor_8h.html", [
      [ "MagnetometerAdaptor", "classMagnetometerAdaptor.html", "classMagnetometerAdaptor" ]
    ] ],
    [ "magnetometeradaptorplugin.h", "magnetometeradaptorplugin_8h.html", [
      [ "MagnetometerAdaptorPlugin", "classMagnetometerAdaptorPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2magnetometeradaptor_2moc__predefs_8h.html", "adaptors_2magnetometeradaptor_2moc__predefs_8h" ]
];