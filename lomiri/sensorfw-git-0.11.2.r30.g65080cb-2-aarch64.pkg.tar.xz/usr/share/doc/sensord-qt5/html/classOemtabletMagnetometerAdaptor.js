var classOemtabletMagnetometerAdaptor =
[
    [ "OemtabletMagnetometerAdaptor", "classOemtabletMagnetometerAdaptor.html#a809fcb46fafe9bb3efc71bddd634595f", null ],
    [ "~OemtabletMagnetometerAdaptor", "classOemtabletMagnetometerAdaptor.html#ad8eb1c8f35d5b18e9635442f7ed34142", null ]
];