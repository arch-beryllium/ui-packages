var dir_3ec8de81d31f211ae5bf0454c673bbbc =
[
    [ "abstractsensor_i.h", "abstractsensor__i_8h.html", "abstractsensor__i_8h" ],
    [ "accelerometersensor_i.h", "accelerometersensor__i_8h.html", "accelerometersensor__i_8h" ],
    [ "alssensor_i.h", "alssensor__i_8h.html", "alssensor__i_8h" ],
    [ "compasssensor_i.h", "compasssensor__i_8h.html", "compasssensor__i_8h" ],
    [ "gyroscopesensor_i.h", "gyroscopesensor__i_8h.html", "gyroscopesensor__i_8h" ],
    [ "humiditysensor_i.h", "humiditysensor__i_8h.html", "humiditysensor__i_8h" ],
    [ "lidsensor_i.h", "lidsensor__i_8h.html", "lidsensor__i_8h" ],
    [ "magnetometersensor_i.h", "magnetometersensor__i_8h.html", "magnetometersensor__i_8h" ],
    [ "moc_predefs.h", "qt-api_2moc__predefs_8h.html", "qt-api_2moc__predefs_8h" ],
    [ "orientationsensor_i.h", "orientationsensor__i_8h.html", "orientationsensor__i_8h" ],
    [ "pressuresensor_i.h", "pressuresensor__i_8h.html", "pressuresensor__i_8h" ],
    [ "proximitysensor_i.h", "proximitysensor__i_8h.html", "proximitysensor__i_8h" ],
    [ "rotationsensor_i.h", "rotationsensor__i_8h.html", "rotationsensor__i_8h" ],
    [ "sensormanager_i.h", "sensormanager__i_8h.html", "sensormanager__i_8h" ],
    [ "sensormanagerinterface.h", "sensormanagerinterface_8h.html", "sensormanagerinterface_8h" ],
    [ "socketreader.h", "socketreader_8h.html", [
      [ "SocketReader", "classSocketReader.html", "classSocketReader" ]
    ] ],
    [ "stepcountersensor_i.h", "stepcountersensor__i_8h.html", "stepcountersensor__i_8h" ],
    [ "tapsensor_i.h", "tapsensor__i_8h.html", "tapsensor__i_8h" ],
    [ "temperaturesensor_i.h", "temperaturesensor__i_8h.html", "temperaturesensor__i_8h" ]
];