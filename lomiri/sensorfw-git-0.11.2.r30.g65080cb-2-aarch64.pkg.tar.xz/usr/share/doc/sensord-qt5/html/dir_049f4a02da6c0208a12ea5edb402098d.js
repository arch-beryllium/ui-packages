var dir_049f4a02da6c0208a12ea5edb402098d =
[
    [ "calibrationfilter.h", "calibrationfilter_8h.html", [
      [ "CalibrationFilter", "classCalibrationFilter.html", "classCalibrationFilter" ]
    ] ],
    [ "magcalibrationchain.h", "magcalibrationchain_8h.html", [
      [ "MagCalibrationChain", "classMagCalibrationChain.html", "classMagCalibrationChain" ]
    ] ],
    [ "magcalibrationchainplugin.h", "magcalibrationchainplugin_8h.html", [
      [ "MagCalibrationChainPlugin", "classMagCalibrationChainPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "chains_2magcalibrationchain_2moc__predefs_8h.html", "chains_2magcalibrationchain_2moc__predefs_8h" ]
];