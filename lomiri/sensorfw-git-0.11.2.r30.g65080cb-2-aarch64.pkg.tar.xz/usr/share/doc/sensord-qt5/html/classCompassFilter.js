var classCompassFilter =
[
    [ "CompassFilter", "classCompassFilter.html#ae338daa548b9f4265b608e59e9e12bd0", null ]
];