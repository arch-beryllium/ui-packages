var dir_66c806a7d3da9ac905bb247e87269999 =
[
    [ "moc_predefs.h", "adaptors_2proximityadaptor-ascii_2moc__predefs_8h.html", "adaptors_2proximityadaptor-ascii_2moc__predefs_8h" ],
    [ "proximityadaptor-ascii.h", "proximityadaptor-ascii_8h.html", [
      [ "ProximityAdaptorAscii", "classProximityAdaptorAscii.html", "classProximityAdaptorAscii" ]
    ] ],
    [ "proximityadaptor-asciiplugin.h", "proximityadaptor-asciiplugin_8h.html", [
      [ "ProximityAdaptorAsciiPlugin", "classProximityAdaptorAsciiPlugin.html", null ]
    ] ]
];