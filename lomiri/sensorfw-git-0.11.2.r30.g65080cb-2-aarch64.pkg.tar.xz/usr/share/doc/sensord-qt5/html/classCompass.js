var classCompass =
[
    [ "Compass", "classCompass.html#a68bd2a073cc0d461b2b46529aae04765", null ],
    [ "Compass", "classCompass.html#a4f1b0b98fb778f94da3fee92ae9bf7bb", null ],
    [ "Compass", "classCompass.html#a828c71066e09e34c234720c6207d2ccd", null ],
    [ "Compass", "classCompass.html#ae46768bdb1cb0c6fa632928f22a737a1", null ],
    [ "data", "classCompass.html#a6eab193036eaa7c9b1c084b8ecf0c6a6", null ],
    [ "degrees", "classCompass.html#a22832ebf48d32a5fafe40cdb9a6a4f28", null ],
    [ "level", "classCompass.html#ab37d08adbb2b180a28f5d0229574bbd0", null ],
    [ "operator=", "classCompass.html#a6af44a3533ba8e200cc9e1aa23a511cc", null ],
    [ "operator==", "classCompass.html#a8a65eced0c87321e1abb2914acf9aff6", null ],
    [ "operator>>", "classCompass.html#aab79cbd181f9db83b74fae53307b6a2c", null ],
    [ "degrees", "classCompass.html#a38df20f500fef57c5cf10415bfb5a08c", null ],
    [ "level", "classCompass.html#acfab121a70abd88e3d362a80b46b513b", null ]
];