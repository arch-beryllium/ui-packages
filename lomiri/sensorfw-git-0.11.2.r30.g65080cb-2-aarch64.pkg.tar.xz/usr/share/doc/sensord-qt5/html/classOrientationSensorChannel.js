var classOrientationSensorChannel =
[
    [ "OrientationSensorChannel", "classOrientationSensorChannel.html#a05e075d7ad2f82c456ca98c08ebf650e", null ],
    [ "~OrientationSensorChannel", "classOrientationSensorChannel.html#a1e4e56e3d3135ce04a9f304288499bb6", null ],
    [ "orientation", "classOrientationSensorChannel.html#af0ecce22cba5a695348fd546a2d8d48a", null ],
    [ "orientationChanged", "classOrientationSensorChannel.html#ac90052d9a0cf240b8952e925a7bcb819", null ],
    [ "start", "classOrientationSensorChannel.html#ae3f1311de6d7326e02ce65bdebaf7146", null ],
    [ "stop", "classOrientationSensorChannel.html#a64085d453c66fd15a458cc2202914fbc", null ],
    [ "orientation", "classOrientationSensorChannel.html#a61a9053472c9c288fa2a0f88b199e01d", null ]
];