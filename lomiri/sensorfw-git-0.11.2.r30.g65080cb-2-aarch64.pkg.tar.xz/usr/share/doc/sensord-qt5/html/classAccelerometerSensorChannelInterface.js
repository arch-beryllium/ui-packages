var classAccelerometerSensorChannelInterface =
[
    [ "AccelerometerSensorChannelInterface", "classAccelerometerSensorChannelInterface.html#a19dc7f57b92adfebd1c902b3839ae40c", null ],
    [ "connectNotify", "classAccelerometerSensorChannelInterface.html#a05c3f3faca605e5442571b9ffdea656a", null ],
    [ "dataAvailable", "classAccelerometerSensorChannelInterface.html#a44975bb071214a574f4497b13793d20e", null ],
    [ "dataReceivedImpl", "classAccelerometerSensorChannelInterface.html#a694efdd8475c9fa27ece75364839037a", null ],
    [ "frameAvailable", "classAccelerometerSensorChannelInterface.html#adda8a1c3a677e4ff52a0588d6c65f450", null ],
    [ "get", "classAccelerometerSensorChannelInterface.html#a0f2d3e9935ea11040819d531781c0c3c", null ],
    [ "value", "classAccelerometerSensorChannelInterface.html#aa224a0c4a076e652266c9c5f0c9082a1", null ]
];