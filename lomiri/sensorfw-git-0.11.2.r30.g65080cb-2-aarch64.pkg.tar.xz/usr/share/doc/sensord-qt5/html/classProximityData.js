var classProximityData =
[
    [ "ProximityData", "classProximityData.html#a0438c17fc2ab6e6f9c7f919cda04986d", null ],
    [ "ProximityData", "classProximityData.html#aaa3139ec93727f916f1e97687b68a1ff", null ],
    [ "withinProximity_", "classProximityData.html#af1e666893b29355111c10d6ee83d6dec", null ]
];