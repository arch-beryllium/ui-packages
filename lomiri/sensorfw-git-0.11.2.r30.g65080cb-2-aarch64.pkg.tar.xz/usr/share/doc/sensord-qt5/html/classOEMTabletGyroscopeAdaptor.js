var classOEMTabletGyroscopeAdaptor =
[
    [ "OEMTabletGyroscopeAdaptor", "classOEMTabletGyroscopeAdaptor.html#a16b25c6fc657c1c5e138448f1a7d7fcc", null ],
    [ "~OEMTabletGyroscopeAdaptor", "classOEMTabletGyroscopeAdaptor.html#ac75df27d3ebf4d5bdade7c8821b5858c", null ]
];