var dir_c015577d6964876c7fb17c6a54908c56 =
[
    [ "moc_predefs.h", "adaptors_2pegatronaccelerometeradaptor_2moc__predefs_8h.html", "adaptors_2pegatronaccelerometeradaptor_2moc__predefs_8h" ],
    [ "pegatronaccelerometeradaptor.h", "pegatronaccelerometeradaptor_8h.html", [
      [ "PegatronAccelerometerAdaptor", "classPegatronAccelerometerAdaptor.html", "classPegatronAccelerometerAdaptor" ]
    ] ],
    [ "pegatronaccelerometeradaptorplugin.h", "pegatronaccelerometeradaptorplugin_8h.html", [
      [ "PegatronAccelerometerAdaptorPlugin", "classPegatronAccelerometerAdaptorPlugin.html", null ]
    ] ]
];