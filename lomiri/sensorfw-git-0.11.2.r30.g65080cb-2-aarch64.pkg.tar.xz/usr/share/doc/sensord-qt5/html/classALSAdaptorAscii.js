var classALSAdaptorAscii =
[
    [ "ALSAdaptorAscii", "classALSAdaptorAscii.html#a6f5f48931d4497fbf211d240a2142d68", null ],
    [ "~ALSAdaptorAscii", "classALSAdaptorAscii.html#a10dd689cb2790f4628d289946632984e", null ],
    [ "setStandbyOverride", "classALSAdaptorAscii.html#aa1b4c80c6794fc286de06b3407520a96", null ],
    [ "startSensor", "classALSAdaptorAscii.html#a9bc9ed179a93c840e2fedcab9fc93523", null ],
    [ "stopSensor", "classALSAdaptorAscii.html#a9fbbfa525078c63603932ac2da83f241", null ]
];