var classCompassSensorChannelInterface =
[
    [ "CompassSensorChannelInterface", "classCompassSensorChannelInterface.html#a80080a88597178c790c64bfb9a46f3dd", null ],
    [ "dataAvailable", "classCompassSensorChannelInterface.html#a3262c625c0849c6ea09a485d8453f5dc", null ],
    [ "dataReceivedImpl", "classCompassSensorChannelInterface.html#a79cb7a8e652e1c11e8fd2d759637b9e6", null ],
    [ "declinationValue", "classCompassSensorChannelInterface.html#a7a2eb9058a587ef14d690c52c24715b7", null ],
    [ "get", "classCompassSensorChannelInterface.html#a1e1fe9e7cf7f63ccc265722b21fb4ab9", null ],
    [ "setUseDeclination", "classCompassSensorChannelInterface.html#ae8218160b314d7345ec5cb874b74087d", null ],
    [ "useDeclination", "classCompassSensorChannelInterface.html#a3e1dd2d1c0180cac90ccfa5c5d30793c", null ],
    [ "declinationvalue", "classCompassSensorChannelInterface.html#a6453da5ee314454105ae9e6b97d94d86", null ],
    [ "usedeclination", "classCompassSensorChannelInterface.html#a70cbbaa33ecd9dc18b440196aa03f987", null ],
    [ "value", "classCompassSensorChannelInterface.html#a3d690dd38eaeb37c11817b01ffe59f26", null ]
];