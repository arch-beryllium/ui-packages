var magneticfield_8h =
[
    [ "MagneticField", "classMagneticField.html", "classMagneticField" ],
    [ "operator<<", "magneticfield_8h.html#abc2a1330451edbbe27e62bf6679149c7", null ],
    [ "operator>>", "magneticfield_8h.html#adec412a0d907fa73ab790bf45121769e", null ]
];