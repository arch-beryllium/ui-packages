var classCompassChain =
[
    [ "CompassChain", "classCompassChain.html#a583360a1edb7fedcfc8fbbd68ce79a96", null ],
    [ "~CompassChain", "classCompassChain.html#a82be1b82ee15557ff41c59fe8f93ebfd", null ],
    [ "compassEnabled", "classCompassChain.html#ae415785e0048d111a607844ba672363e", null ],
    [ "declinationValue", "classCompassChain.html#a9c77fbc2aefe0c06416f966417de4524", null ],
    [ "resetCalibration", "classCompassChain.html#a0f7a0f37d6875a6b3ca868a4062154b3", null ],
    [ "setCompassEnabled", "classCompassChain.html#a627079905dbb0a91d6e4f75b46698af4", null ],
    [ "start", "classCompassChain.html#a323817f455a05dbc616fb30552b0c95f", null ],
    [ "stop", "classCompassChain.html#af693b4c953d2d0cbd19963e438caf6ca", null ],
    [ "compassEnabled", "classCompassChain.html#a14eb6a537f017aca82f88f4972ec15f2", null ],
    [ "declinationValue", "classCompassChain.html#a5337a9293e48401df8895bb6efcf8fe5", null ]
];