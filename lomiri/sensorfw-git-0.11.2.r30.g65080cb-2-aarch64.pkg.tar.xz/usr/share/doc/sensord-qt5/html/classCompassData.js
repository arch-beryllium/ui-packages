var classCompassData =
[
    [ "CompassData", "classCompassData.html#ad8d907a2c76eeb63ec1a9d08384ae4c2", null ],
    [ "CompassData", "classCompassData.html#acf3953a213e3472c44068f55c7c74066", null ],
    [ "CompassData", "classCompassData.html#a4f07c6862622733d72816b9a444c912c", null ],
    [ "correctedDegrees_", "classCompassData.html#ad8111a6330cc4829c1fa37b823b3a6be", null ],
    [ "degrees_", "classCompassData.html#a589775d59fdbb9f561d6c551f50d2641", null ],
    [ "level_", "classCompassData.html#a2bcdbf4302f984a2f521a06194c0d688", null ],
    [ "rawDegrees_", "classCompassData.html#a8bf425f5654f73829d4bf9a8b7f7fce0", null ]
];