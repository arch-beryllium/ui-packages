var classDeclinationFilter =
[
    [ "declinationCorrection", "classDeclinationFilter.html#ade7ca13833892cd6d29665260d18d448", null ],
    [ "declinationCorrection", "classDeclinationFilter.html#a35b43ac13c6e3549dd30d4d6aabb0176", null ]
];