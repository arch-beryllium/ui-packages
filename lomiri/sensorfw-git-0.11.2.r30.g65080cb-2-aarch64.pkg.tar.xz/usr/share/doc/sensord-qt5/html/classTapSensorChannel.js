var classTapSensorChannel =
[
    [ "TapSensorChannel", "classTapSensorChannel.html#ac61dd543cb92bed5143abef0b66c36bf", null ],
    [ "~TapSensorChannel", "classTapSensorChannel.html#ad5fd62fc4fb9dc6f1dd41f59ba26e804", null ],
    [ "dataAvailable", "classTapSensorChannel.html#a274fea55af93c08a1c3a42d0593cc559", null ],
    [ "start", "classTapSensorChannel.html#aca647ecfa6c00b32aa966639f763afd5", null ],
    [ "stop", "classTapSensorChannel.html#ac9fc34fc8dce5029c2a7602b9c859969", null ]
];