var dir_045937fd074c9ede2c44aa337e162e65 =
[
    [ "moc_predefs.h", "adaptors_2mpu6050accelerometer_2moc__predefs_8h.html", "adaptors_2mpu6050accelerometer_2moc__predefs_8h" ],
    [ "mpu6050accelerometeradaptor.h", "mpu6050accelerometeradaptor_8h.html", "mpu6050accelerometeradaptor_8h" ],
    [ "mpu6050accelerometeradaptorplugin.h", "mpu6050accelerometeradaptorplugin_8h.html", [
      [ "Mpu6050AccelerometerAdaptorPlugin", "classMpu6050AccelerometerAdaptorPlugin.html", null ]
    ] ]
];