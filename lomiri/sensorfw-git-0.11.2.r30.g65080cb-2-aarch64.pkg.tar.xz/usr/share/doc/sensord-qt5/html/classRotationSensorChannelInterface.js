var classRotationSensorChannelInterface =
[
    [ "RotationSensorChannelInterface", "classRotationSensorChannelInterface.html#a3813b95b723f372289920705678d4927", null ],
    [ "connectNotify", "classRotationSensorChannelInterface.html#aba2429d04a014528c961f2c51553e185", null ],
    [ "dataAvailable", "classRotationSensorChannelInterface.html#ace17d689f4e8fb74a79d185eb5b1134d", null ],
    [ "dataReceivedImpl", "classRotationSensorChannelInterface.html#a76ac8c4b5b5092d0367a2f912d922a92", null ],
    [ "frameAvailable", "classRotationSensorChannelInterface.html#aef3baf662a59ad84acecacc0fd6b06fd", null ],
    [ "hasZ", "classRotationSensorChannelInterface.html#a365979272c4f1153757b47beb4dd99b7", null ],
    [ "rotation", "classRotationSensorChannelInterface.html#ac87c988dd1cb29b07837767dd4fb8a5f", null ],
    [ "hasZ", "classRotationSensorChannelInterface.html#a1dd27508f90cc5fdfb6f330d50f04864", null ],
    [ "rotation", "classRotationSensorChannelInterface.html#a81dbba1646c12e7cda4173fddad69393", null ]
];