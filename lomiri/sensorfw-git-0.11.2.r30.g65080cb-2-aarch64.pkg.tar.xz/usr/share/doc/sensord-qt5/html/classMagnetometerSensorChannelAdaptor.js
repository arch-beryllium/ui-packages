var classMagnetometerSensorChannelAdaptor =
[
    [ "MagnetometerSensorChannelAdaptor", "classMagnetometerSensorChannelAdaptor.html#a30502b9624f4899479bcff32d57941e5", null ],
    [ "dataAvailable", "classMagnetometerSensorChannelAdaptor.html#a5b5dfdee98b04ae954bc7f633652e6a1", null ],
    [ "magneticField", "classMagnetometerSensorChannelAdaptor.html#af4c0912b2978cc01657824f99be9fcaf", null ],
    [ "reset", "classMagnetometerSensorChannelAdaptor.html#a9ae2f4b04d879bb7504f5ebfc8dac05c", null ],
    [ "magneticField", "classMagnetometerSensorChannelAdaptor.html#a59ef9706ad8f2dea5bd14df5d5cb8523", null ]
];