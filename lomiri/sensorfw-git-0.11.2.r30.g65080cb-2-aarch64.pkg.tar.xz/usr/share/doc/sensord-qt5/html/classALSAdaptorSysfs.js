var classALSAdaptorSysfs =
[
    [ "ALSAdaptorSysfs", "classALSAdaptorSysfs.html#a36a691ddcfe1c1e8937565dedbdee484", null ],
    [ "~ALSAdaptorSysfs", "classALSAdaptorSysfs.html#a633b2ea74a3b753b238ed49685b44f18", null ],
    [ "setStandbyOverride", "classALSAdaptorSysfs.html#a0a69765a5af894fa14b2d9f549651ce9", null ]
];