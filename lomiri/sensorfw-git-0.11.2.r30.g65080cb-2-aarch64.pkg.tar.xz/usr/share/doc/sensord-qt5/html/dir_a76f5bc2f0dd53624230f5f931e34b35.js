var dir_a76f5bc2f0dd53624230f5f931e34b35 =
[
    [ "accelerometerchain.h", "accelerometerchain_8h.html", [
      [ "AccelerometerChain", "classAccelerometerChain.html", "classAccelerometerChain" ]
    ] ],
    [ "accelerometerchainplugin.h", "accelerometerchainplugin_8h.html", [
      [ "AccelerometerChainPlugin", "classAccelerometerChainPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "chains_2accelerometerchain_2moc__predefs_8h.html", "chains_2accelerometerchain_2moc__predefs_8h" ]
];