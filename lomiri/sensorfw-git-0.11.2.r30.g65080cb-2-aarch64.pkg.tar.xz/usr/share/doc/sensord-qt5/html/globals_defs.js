var globals_defs =
[
    [ "_", "globals_defs.html", null ],
    [ "a", "globals_defs_a.html", null ],
    [ "i", "globals_defs_i.html", null ],
    [ "l", "globals_defs_l.html", null ],
    [ "u", "globals_defs_u.html", null ],
    [ "x", "globals_defs_x.html", null ],
    [ "y", "globals_defs_y.html", null ],
    [ "z", "globals_defs_z.html", null ]
];