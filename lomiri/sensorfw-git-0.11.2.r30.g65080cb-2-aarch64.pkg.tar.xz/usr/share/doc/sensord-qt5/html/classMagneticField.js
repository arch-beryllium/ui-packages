var classMagneticField =
[
    [ "MagneticField", "classMagneticField.html#ad10a16d53feef92eb78ed4789ba6fc0f", null ],
    [ "MagneticField", "classMagneticField.html#a7f4b516ce37939413311df7a57533a5d", null ],
    [ "MagneticField", "classMagneticField.html#a4f43d30397fdcb47f72c9db16b9f373e", null ],
    [ "data", "classMagneticField.html#a51ad3151a8b765ae17eb760bd0e36d39", null ],
    [ "level", "classMagneticField.html#a319ebab4a190b67d9c05700c1a3e3d6c", null ],
    [ "operator=", "classMagneticField.html#aa64ef26df25ede4cbd43a8a53c6b8e9c", null ],
    [ "operator==", "classMagneticField.html#a6e3c957b72459ccc0bd784088884a46e", null ],
    [ "rx", "classMagneticField.html#ad3ccec572d1fc0cb31df1cf4c4295e3f", null ],
    [ "ry", "classMagneticField.html#adb8e77d63d7f339c22a9acf6fe8563c3", null ],
    [ "rz", "classMagneticField.html#a0847815787254ba3cd66e2ba89becb63", null ],
    [ "timestamp", "classMagneticField.html#a9332e51cb6369ab72707d0d0c67212af", null ],
    [ "x", "classMagneticField.html#acf30d6238bb47b3be4bcffba1a177bdd", null ],
    [ "y", "classMagneticField.html#a5a31d89d1504e37d53263561d7aa5064", null ],
    [ "z", "classMagneticField.html#a1fffd8cc7e50c96a1729cb8547dd1baa", null ],
    [ "operator>>", "classMagneticField.html#adec412a0d907fa73ab790bf45121769e", null ]
];