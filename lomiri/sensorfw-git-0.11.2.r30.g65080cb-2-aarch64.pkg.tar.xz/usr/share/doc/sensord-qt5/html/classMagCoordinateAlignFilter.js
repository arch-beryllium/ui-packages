var classMagCoordinateAlignFilter =
[
    [ "MagCoordinateAlignFilter", "classMagCoordinateAlignFilter.html#a2a012eb30ba38366404edf4b33429a76", null ],
    [ "matrix", "classMagCoordinateAlignFilter.html#a0e38f5fd228361768e33cda201c40754", null ],
    [ "setMatrix", "classMagCoordinateAlignFilter.html#aa821de8ba92531e403ae84776cd30ae8", null ],
    [ "transMatrix", "classMagCoordinateAlignFilter.html#ad335cdee7f1c2f73f26da61abaa27020", null ]
];