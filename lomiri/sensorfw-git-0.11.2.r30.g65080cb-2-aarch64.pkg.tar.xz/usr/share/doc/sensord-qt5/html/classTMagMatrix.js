var classTMagMatrix =
[
    [ "TMagMatrix", "classTMagMatrix.html#ac4d71021f30da329d0a4cc98304a9e53", null ],
    [ "TMagMatrix", "classTMagMatrix.html#a5fc46c23750af9d232d78e82e8eb4e6a", null ],
    [ "TMagMatrix", "classTMagMatrix.html#ab8b45118624eb835b06152bdf7127266", null ],
    [ "get", "classTMagMatrix.html#a216e6cba5e6af51ae99e9a58bf4e4db4", null ],
    [ "setMatrix", "classTMagMatrix.html#a8b4b6b7cdf0a2743cbc2c728fd99150b", null ],
    [ "data_", "classTMagMatrix.html#a808c5e6b635bbe0fff9cdbc608056752", null ]
];