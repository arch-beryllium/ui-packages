var classLidSensorChannelAdaptor =
[
    [ "LidSensorChannelAdaptor", "classLidSensorChannelAdaptor.html#aedac51864567cad3c9d7d8cdc3cc8f75", null ],
    [ "closed", "classLidSensorChannelAdaptor.html#aef1a1bd46deffb0664d65a1edd35d639", null ],
    [ "lidChanged", "classLidSensorChannelAdaptor.html#aab3b7da7355334b5ecdfeee85fbe8e96", null ],
    [ "closed", "classLidSensorChannelAdaptor.html#a5fbe6e9be6fa72958f41a091f3875e6f", null ]
];