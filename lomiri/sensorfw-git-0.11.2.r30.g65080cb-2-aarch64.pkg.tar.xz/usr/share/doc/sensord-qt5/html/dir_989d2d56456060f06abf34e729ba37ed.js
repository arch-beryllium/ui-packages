var dir_989d2d56456060f06abf34e729ba37ed =
[
    [ "gyroscopeplugin.h", "gyroscopeplugin_8h.html", [
      [ "GyroscopePlugin", "classGyroscopePlugin.html", null ]
    ] ],
    [ "gyroscopesensor.h", "gyroscopesensor_8h.html", [
      [ "GyroscopeSensorChannel", "classGyroscopeSensorChannel.html", "classGyroscopeSensorChannel" ]
    ] ],
    [ "gyroscopesensor_a.h", "gyroscopesensor__a_8h.html", [
      [ "GyroscopeSensorChannelAdaptor", "classGyroscopeSensorChannelAdaptor.html", "classGyroscopeSensorChannelAdaptor" ]
    ] ],
    [ "moc_predefs.h", "sensors_2gyroscopesensor_2moc__predefs_8h.html", "sensors_2gyroscopesensor_2moc__predefs_8h" ]
];