var compass_8h =
[
    [ "Compass", "classCompass.html", "classCompass" ],
    [ "operator<<", "compass_8h.html#a39dec0c930f06521cc847c58c5d674a8", null ],
    [ "operator>>", "compass_8h.html#aab79cbd181f9db83b74fae53307b6a2c", null ]
];