var dir_2971b7f94ec909d55f793c86ffe61455 =
[
    [ "moc_predefs.h", "sensors_2tapsensor_2moc__predefs_8h.html", "sensors_2tapsensor_2moc__predefs_8h" ],
    [ "tapplugin.h", "tapplugin_8h.html", [
      [ "TapPlugin", "classTapPlugin.html", null ]
    ] ],
    [ "tapsensor.h", "tapsensor_8h.html", [
      [ "TapSensorChannel", "classTapSensorChannel.html", "classTapSensorChannel" ]
    ] ],
    [ "tapsensor_a.h", "tapsensor__a_8h.html", [
      [ "TapSensorChannelAdaptor", "classTapSensorChannelAdaptor.html", "classTapSensorChannelAdaptor" ]
    ] ]
];