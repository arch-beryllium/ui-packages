var classLidSensorAdaptorEvdev =
[
    [ "LidSensorAdaptorEvdev", "classLidSensorAdaptorEvdev.html#ae6f796a342c3ac98cd1887b5f734af3f", null ],
    [ "~LidSensorAdaptorEvdev", "classLidSensorAdaptorEvdev.html#a5a9a45c5bc7fec285e833873306b56fc", null ],
    [ "init", "classLidSensorAdaptorEvdev.html#a884c565df89ba43b3dbfaee46f1d5eb2", null ],
    [ "resume", "classLidSensorAdaptorEvdev.html#a9d1faf5be366a7160ec079d0b1d83d83", null ],
    [ "standby", "classLidSensorAdaptorEvdev.html#a364122a3100fc9ff48954f3c346d72d4", null ],
    [ "startSensor", "classLidSensorAdaptorEvdev.html#a977c0943271d8f707cc89f2773f2b3a7", null ],
    [ "stopSensor", "classLidSensorAdaptorEvdev.html#aeaaf644792da7cbbeda74634b080b2a4", null ]
];