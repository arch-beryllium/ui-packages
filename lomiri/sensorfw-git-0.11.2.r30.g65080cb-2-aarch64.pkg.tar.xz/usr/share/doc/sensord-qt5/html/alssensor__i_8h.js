var alssensor__i_8h =
[
    [ "ALSSensorChannelInterface", "classALSSensorChannelInterface.html", "classALSSensorChannelInterface" ],
    [ "ALSSensor", "alssensor__i_8h.html#a5c938d6cd651f3697dd399ff31c4a6ba", null ]
];