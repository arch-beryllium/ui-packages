var classRotationSensorChannelAdaptor =
[
    [ "RotationSensorChannelAdaptor", "classRotationSensorChannelAdaptor.html#adb1a76fbc805b4869622b80501d0536a", null ],
    [ "dataAvailable", "classRotationSensorChannelAdaptor.html#a68c141b6f9555a6b983a69a66a744ebc", null ],
    [ "hasZ", "classRotationSensorChannelAdaptor.html#abbcadcf9ca89d62b6fe573469ba68890", null ],
    [ "rotation", "classRotationSensorChannelAdaptor.html#aa519cfc0ad1cd09c70640a90b783f3ef", null ],
    [ "hasZ", "classRotationSensorChannelAdaptor.html#a053d518b392019e7e3a53b8cfc187c15", null ],
    [ "rotation", "classRotationSensorChannelAdaptor.html#aa70d7630af26f1e933b4f69bbe2d7e57", null ]
];