var dir_2e1f72bf792a0af7e5b7e8cad03cf1c4 =
[
    [ "moc_predefs.h", "adaptors_2proximityadaptor-evdev_2moc__predefs_8h.html", "adaptors_2proximityadaptor-evdev_2moc__predefs_8h" ],
    [ "proximityadaptor-evdev.h", "proximityadaptor-evdev_8h.html", [
      [ "ProximityAdaptorEvdev", "classProximityAdaptorEvdev.html", "classProximityAdaptorEvdev" ]
    ] ],
    [ "proximityadaptor-evdevplugin.h", "proximityadaptor-evdevplugin_8h.html", [
      [ "ProximityAdaptorEvdevPlugin", "classProximityAdaptorEvdevPlugin.html", null ]
    ] ]
];