var dir_d0244a4e54c29b9d6c26f5a7ae6c0817 =
[
    [ "oemtabletgyroscopeadaptor.h", "oemtabletgyroscopeadaptor_8h.html", [
      [ "OEMTabletGyroscopeAdaptor", "classOEMTabletGyroscopeAdaptor.html", "classOEMTabletGyroscopeAdaptor" ]
    ] ],
    [ "oemtabletgyroscopeadaptorplugin.h", "oemtabletgyroscopeadaptorplugin_8h.html", [
      [ "OEMTabletGyroscopeAdaptorPlugin", "classOEMTabletGyroscopeAdaptorPlugin.html", null ]
    ] ]
];