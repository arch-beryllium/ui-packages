var classAccelerometerAdaptor =
[
    [ "AccelerometerAdaptor", "classAccelerometerAdaptor.html#ad912e20f351ac416bf73ef35edc0a61c", null ],
    [ "~AccelerometerAdaptor", "classAccelerometerAdaptor.html#a897d1b75a0dabc353e1945a9b58ffae9", null ],
    [ "evaluateIntervalRequests", "classAccelerometerAdaptor.html#a85d9847733f71fec6af0c9d7869299bd", null ],
    [ "resume", "classAccelerometerAdaptor.html#a5d37fd718336c2ea0c85e7166fd0252b", null ],
    [ "standby", "classAccelerometerAdaptor.html#aa6fb821c4977701cd3f1492f6f3eb11b", null ],
    [ "startSensor", "classAccelerometerAdaptor.html#a6266218013a12e033d7ac90b34c53cb1", null ],
    [ "stopSensor", "classAccelerometerAdaptor.html#ae7643c9df99e39b6129977ac990811ee", null ]
];