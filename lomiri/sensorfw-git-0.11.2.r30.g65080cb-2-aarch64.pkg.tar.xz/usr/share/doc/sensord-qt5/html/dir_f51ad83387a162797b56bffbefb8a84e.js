var dir_f51ad83387a162797b56bffbefb8a84e =
[
    [ "moc_predefs.h", "adaptors_2temperatureadaptor_2moc__predefs_8h.html", "adaptors_2temperatureadaptor_2moc__predefs_8h" ],
    [ "temperatureadaptor.h", "temperatureadaptor_8h.html", [
      [ "TemperatureAdaptor", "classTemperatureAdaptor.html", "classTemperatureAdaptor" ]
    ] ],
    [ "temperatureadaptorplugin.h", "temperatureadaptorplugin_8h.html", [
      [ "TemperatureAdaptorPlugin", "classTemperatureAdaptorPlugin.html", null ]
    ] ]
];