var classGyroscopeSensorChannelInterface =
[
    [ "GyroscopeSensorChannelInterface", "classGyroscopeSensorChannelInterface.html#a0e3aa50e870e0ebb850e5f28106a1026", null ],
    [ "connectNotify", "classGyroscopeSensorChannelInterface.html#a0061651d95d5a71c18094da62d08f621", null ],
    [ "dataAvailable", "classGyroscopeSensorChannelInterface.html#a99ec110bda15dcd3935faa8a0956bfb5", null ],
    [ "dataReceivedImpl", "classGyroscopeSensorChannelInterface.html#abf9b34d7fb8fcdd983610805258e1d59", null ],
    [ "frameAvailable", "classGyroscopeSensorChannelInterface.html#aaa59583e443221e7ffde8f959b98df72", null ],
    [ "get", "classGyroscopeSensorChannelInterface.html#a65b63653f773b58a74c1e0b05f34a70e", null ],
    [ "value", "classGyroscopeSensorChannelInterface.html#a732b1401bb844ef06cec32e0504adbcc", null ]
];