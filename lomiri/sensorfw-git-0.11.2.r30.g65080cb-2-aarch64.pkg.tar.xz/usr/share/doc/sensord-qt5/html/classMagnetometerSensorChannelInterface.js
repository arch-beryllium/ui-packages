var classMagnetometerSensorChannelInterface =
[
    [ "MagnetometerSensorChannelInterface", "classMagnetometerSensorChannelInterface.html#aee72771a798036edea76c9154c82ef1b", null ],
    [ "connectNotify", "classMagnetometerSensorChannelInterface.html#a44ebee84debe8399ac84ca4f5dbdf368", null ],
    [ "dataAvailable", "classMagnetometerSensorChannelInterface.html#a8fb58e73035d9d17cf0e64c2b1394efb", null ],
    [ "dataReceivedImpl", "classMagnetometerSensorChannelInterface.html#a0cbb435ad8ef2bb8bb0d507d1e53184d", null ],
    [ "frameAvailable", "classMagnetometerSensorChannelInterface.html#a62664fc8d6c6b57a5367d0c77815618f", null ],
    [ "magneticField", "classMagnetometerSensorChannelInterface.html#ab6018dc8e03502675579c4e81e9969d0", null ],
    [ "reset", "classMagnetometerSensorChannelInterface.html#a9d5ce83d80b6e9d69bfc0d7066555d65", null ],
    [ "magneticField", "classMagnetometerSensorChannelInterface.html#ab529529b802bdc62592abeae84d070e3", null ]
];