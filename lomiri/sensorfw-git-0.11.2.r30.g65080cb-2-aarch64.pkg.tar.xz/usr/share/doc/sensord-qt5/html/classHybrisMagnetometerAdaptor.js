var classHybrisMagnetometerAdaptor =
[
    [ "HybrisMagnetometerAdaptor", "classHybrisMagnetometerAdaptor.html#a5c361e4c8842bd32894e3102ae77ca06", null ],
    [ "~HybrisMagnetometerAdaptor", "classHybrisMagnetometerAdaptor.html#aced0eaf4cb571000ec3747e13d64014a", null ],
    [ "init", "classHybrisMagnetometerAdaptor.html#a8b34b4cbdac6195dc6dbc7add2085312", null ],
    [ "processSample", "classHybrisMagnetometerAdaptor.html#ae9e5d5336cc09eb5299101ee4f0a8b23", null ],
    [ "startSensor", "classHybrisMagnetometerAdaptor.html#abb6e3962adcf68b61bad3a3c9c0f061b", null ],
    [ "stopSensor", "classHybrisMagnetometerAdaptor.html#abe3f6eaac406b7147d89f27a6ebc73df", null ]
];