var classGyroAdaptorEvdev =
[
    [ "GyroAdaptorEvdev", "classGyroAdaptorEvdev.html#a67f5fbe4c8419ecce6e590fea264cb0d", null ],
    [ "~GyroAdaptorEvdev", "classGyroAdaptorEvdev.html#a0fa8adfd990d454ff9cc9d1a669664f5", null ],
    [ "evaluateIntervalRequests", "classGyroAdaptorEvdev.html#a38ccf8fc1d4a12f1376627a636dd65c9", null ],
    [ "resume", "classGyroAdaptorEvdev.html#a26aab17e2b697eb4f1780adfbef6caea", null ],
    [ "standby", "classGyroAdaptorEvdev.html#a7ad30d750d3e8401a1c209a8d9dec2a5", null ],
    [ "startSensor", "classGyroAdaptorEvdev.html#aba9694ce33d590f63efff46e0a54cccf", null ],
    [ "stopSensor", "classGyroAdaptorEvdev.html#a10ca4023b4a15c7cfdfa2dc9927e019a", null ]
];