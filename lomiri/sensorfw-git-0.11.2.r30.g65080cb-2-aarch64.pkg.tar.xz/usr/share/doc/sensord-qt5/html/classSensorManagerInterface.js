var classSensorManagerInterface =
[
    [ "SensorManagerInterface", "classSensorManagerInterface.html#ac5da2ae9d70f76e701f2805251d02446", null ],
    [ "~SensorManagerInterface", "classSensorManagerInterface.html#a10e8c3dca72344676af8e67ae983177e", null ],
    [ "interface", "classSensorManagerInterface.html#af495ad72b313f3c8908690b3987bb52d", null ],
    [ "registeredAndCorrectClassName", "classSensorManagerInterface.html#aa4d90c69be162da99d45b72eb76fb754", null ],
    [ "registerSensorInterface", "classSensorManagerInterface.html#a377620ab890e077e4864f3a5a86f0310", null ],
    [ "releaseInterface", "classSensorManagerInterface.html#acd9fefbada25a3c74635e4d9d240cefe", null ],
    [ "sensorInterfaceMap_", "classSensorManagerInterface.html#a5c85e21afec837288f334b988f72ca69", null ]
];