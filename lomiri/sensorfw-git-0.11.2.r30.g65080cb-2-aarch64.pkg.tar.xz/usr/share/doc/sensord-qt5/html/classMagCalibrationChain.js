var classMagCalibrationChain =
[
    [ "MagCalibrationChain", "classMagCalibrationChain.html#a6482f10affff7b6b080d1be2129a13a6", null ],
    [ "~MagCalibrationChain", "classMagCalibrationChain.html#a9ffc1aaa8e945473c8aad8aa7182254f", null ],
    [ "resetCalibration", "classMagCalibrationChain.html#a2bac92328f480e4a0475d5abe15d8383", null ],
    [ "start", "classMagCalibrationChain.html#ab364ba1de17b0a382d067fca73bfcc5d", null ],
    [ "stop", "classMagCalibrationChain.html#a6ed372c537e1cbabd22c07976fe96558", null ]
];