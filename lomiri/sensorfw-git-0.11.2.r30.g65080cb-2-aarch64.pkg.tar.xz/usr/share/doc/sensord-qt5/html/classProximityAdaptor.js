var classProximityAdaptor =
[
    [ "DeviceType", "classProximityAdaptor.html#a342be9e98576633c26c8cdc5a5890143", [
      [ "DeviceUnknown", "classProximityAdaptor.html#a342be9e98576633c26c8cdc5a5890143aa3060c3888f1caad880be7b79a022638", null ],
      [ "RM680", "classProximityAdaptor.html#a342be9e98576633c26c8cdc5a5890143a2210ebc2d8bab018cf38d2e40935cf74", null ],
      [ "RM696", "classProximityAdaptor.html#a342be9e98576633c26c8cdc5a5890143ac292dc34cca3752aa4a2b7e22dd01a41", null ],
      [ "NCDK", "classProximityAdaptor.html#a342be9e98576633c26c8cdc5a5890143abfc70e7d120518c7142a4ed104999e2f", null ]
    ] ],
    [ "ProximityAdaptor", "classProximityAdaptor.html#a030d491c712f48626e9be50a799b81c1", null ],
    [ "~ProximityAdaptor", "classProximityAdaptor.html#a6d34b8e52029d2f1f15175d37b6bb6ef", null ],
    [ "startSensor", "classProximityAdaptor.html#a49002965c2bbce92447ec28890df045e", null ],
    [ "stopSensor", "classProximityAdaptor.html#a924e443042c20dc4f1dab2f136723261", null ]
];