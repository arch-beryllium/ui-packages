var classMagnetometerAdaptor =
[
    [ "MagnetometerAdaptor", "classMagnetometerAdaptor.html#a10213a6f49adff968fe2700e472348bd", null ],
    [ "~MagnetometerAdaptor", "classMagnetometerAdaptor.html#a76874bf80f89cbce14d501ca02947f49", null ],
    [ "setInterval", "classMagnetometerAdaptor.html#ad443b216d3f30aaee1b70b33daeac20f", null ],
    [ "overflowLimit", "classMagnetometerAdaptor.html#a184f34d9d5563fcdab6f10c1412acf9e", null ]
];