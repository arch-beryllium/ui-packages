var classMagnetometerSensorChannel =
[
    [ "MagnetometerSensorChannel", "classMagnetometerSensorChannel.html#a398bc3cf20cf07545c0f18bb6cfcbd53", null ],
    [ "~MagnetometerSensorChannel", "classMagnetometerSensorChannel.html#a652d4d0b95fce3449d2a98fbcd0ef213", null ],
    [ "dataAvailable", "classMagnetometerSensorChannel.html#a266464f1d7b91574e71f2e5ae027183d", null ],
    [ "downsamplingSupported", "classMagnetometerSensorChannel.html#adaa41c3583cebc6cd60331c5bee33851", null ],
    [ "internalData", "classMagnetometerSensorChannel.html#a70c73f8450d74ad98303160acba50725", null ],
    [ "magneticField", "classMagnetometerSensorChannel.html#a6ba6f0d59cd8dfa36232f2d2f183f8dc", null ],
    [ "removeSession", "classMagnetometerSensorChannel.html#a7e8bda50dbc0b27a0b97873a5fa170c0", null ],
    [ "resetCalibration", "classMagnetometerSensorChannel.html#ae0e6e457e3e9e42c85f11c8bc9d6965c", null ],
    [ "setDataRange", "classMagnetometerSensorChannel.html#a0ac24ed49b9d0d89b9c77ff2d01adf98", null ],
    [ "start", "classMagnetometerSensorChannel.html#a5b02861e0d3350704d9b1052d2e4c904", null ],
    [ "stop", "classMagnetometerSensorChannel.html#ab93c34e4bff45df9ab94650cfddc53ed", null ],
    [ "magneticField", "classMagnetometerSensorChannel.html#aa229f31931ab8284a647081511dd9df2", null ]
];