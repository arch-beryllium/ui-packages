var classMagnetometerAdaptorNCDK =
[
    [ "MagnetometerAdaptorNCDK", "classMagnetometerAdaptorNCDK.html#abb663e323c49e0ba4a74eb3c2b131df1", null ],
    [ "~MagnetometerAdaptorNCDK", "classMagnetometerAdaptorNCDK.html#a26508e07ba009191605ff76746f5cb7a", null ],
    [ "setInterval", "classMagnetometerAdaptorNCDK.html#a6a76b7d884a4ba9c07206814d3cd81f0", null ],
    [ "startSensor", "classMagnetometerAdaptorNCDK.html#aad4046c6997209a3109fc3868b774481", null ],
    [ "stopSensor", "classMagnetometerAdaptorNCDK.html#af3384d305b9abdbd3595fdc608a065bf", null ],
    [ "overflowLimit", "classMagnetometerAdaptorNCDK.html#a86d6b4705d256f1710d18366c3afc6d9", null ]
];