var dir_055b8aed8e2ff52f4da5d2103f48322d =
[
    [ "magnetometerplugin.h", "magnetometerplugin_8h.html", [
      [ "MagnetometerPlugin", "classMagnetometerPlugin.html", null ]
    ] ],
    [ "magnetometerscalefilter.h", "magnetometerscalefilter_8h.html", [
      [ "MagnetometerScaleFilter", "classMagnetometerScaleFilter.html", "classMagnetometerScaleFilter" ]
    ] ],
    [ "magnetometersensor.h", "magnetometersensor_8h.html", [
      [ "MagnetometerSensorChannel", "classMagnetometerSensorChannel.html", "classMagnetometerSensorChannel" ]
    ] ],
    [ "magnetometersensor_a.h", "magnetometersensor__a_8h.html", [
      [ "MagnetometerSensorChannelAdaptor", "classMagnetometerSensorChannelAdaptor.html", "classMagnetometerSensorChannelAdaptor" ]
    ] ],
    [ "moc_predefs.h", "sensors_2magnetometersensor_2moc__predefs_8h.html", "sensors_2magnetometersensor_2moc__predefs_8h" ]
];