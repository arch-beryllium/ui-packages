var dir_63bdf4235990fbd70da8863ef6779660 =
[
    [ "magnetometeradaptor-ascii.h", "magnetometeradaptor-ascii_8h.html", [
      [ "MagnetometerAdaptorAscii", "classMagnetometerAdaptorAscii.html", "classMagnetometerAdaptorAscii" ]
    ] ],
    [ "magnetometeradaptor-asciiplugin.h", "magnetometeradaptor-asciiplugin_8h.html", [
      [ "MagnetometerAdaptorAsciiPlugin", "classMagnetometerAdaptorAsciiPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2magnetometeradaptor-ascii_2moc__predefs_8h.html", "adaptors_2magnetometeradaptor-ascii_2moc__predefs_8h" ]
];