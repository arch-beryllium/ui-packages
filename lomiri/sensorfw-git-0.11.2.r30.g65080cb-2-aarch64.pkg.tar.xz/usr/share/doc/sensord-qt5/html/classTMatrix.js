var classTMatrix =
[
    [ "TMatrix", "classTMatrix.html#a3c968589426334c86f505e8e39b85c2c", null ],
    [ "TMatrix", "classTMatrix.html#a329ac7ec232fe01555a7a96e45e5acca", null ],
    [ "TMatrix", "classTMatrix.html#a93ce3b538b076561d36f30cf05ca4f6b", null ],
    [ "get", "classTMatrix.html#a2b44f0f85b717512129a1957bd37cab4", null ],
    [ "setMatrix", "classTMatrix.html#a449c9b56219925db05da95b23c2cfa15", null ],
    [ "data_", "classTMatrix.html#a3d99dc6a7152e5ec9a313c199a79d6d7", null ]
];