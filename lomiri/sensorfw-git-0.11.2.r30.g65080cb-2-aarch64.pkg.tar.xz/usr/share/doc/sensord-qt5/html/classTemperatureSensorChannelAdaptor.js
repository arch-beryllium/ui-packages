var classTemperatureSensorChannelAdaptor =
[
    [ "TemperatureSensorChannelAdaptor", "classTemperatureSensorChannelAdaptor.html#ac3a347be7b564f31cd5d4883c9961d76", null ],
    [ "temperature", "classTemperatureSensorChannelAdaptor.html#a4accc9d4dd7812b9ca6de620e2fb4267", null ],
    [ "temperatureChanged", "classTemperatureSensorChannelAdaptor.html#a942c332ff3795e52aca4ae22bb28083f", null ],
    [ "temperature", "classTemperatureSensorChannelAdaptor.html#adf80e47e54c16b3b4c96090b7d3e5fe4", null ]
];