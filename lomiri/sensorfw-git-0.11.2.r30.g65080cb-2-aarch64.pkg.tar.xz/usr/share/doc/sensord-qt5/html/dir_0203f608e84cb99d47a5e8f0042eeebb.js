var dir_0203f608e84cb99d47a5e8f0042eeebb =
[
    [ "hybrismagnetometeradaptor.h", "hybrismagnetometeradaptor_8h.html", [
      [ "HybrisMagnetometerAdaptor", "classHybrisMagnetometerAdaptor.html", "classHybrisMagnetometerAdaptor" ]
    ] ],
    [ "hybrismagnetometeradaptorplugin.h", "hybrismagnetometeradaptorplugin_8h.html", [
      [ "HybrisMagnetometerAdaptorPlugin", "classHybrisMagnetometerAdaptorPlugin.html", null ]
    ] ]
];