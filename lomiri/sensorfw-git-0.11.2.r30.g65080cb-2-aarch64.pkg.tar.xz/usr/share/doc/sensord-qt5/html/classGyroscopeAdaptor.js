var classGyroscopeAdaptor =
[
    [ "GyroscopeAdaptor", "classGyroscopeAdaptor.html#ad28e49352add85ca0fdb2d4c26f87d1a", null ],
    [ "~GyroscopeAdaptor", "classGyroscopeAdaptor.html#a29bb471fe53c27504e842b0565e17d7c", null ],
    [ "interval", "classGyroscopeAdaptor.html#a6bc61ad83a17e5d7ca5f7825524e56c7", null ],
    [ "setInterval", "classGyroscopeAdaptor.html#a97b38d43a70c393f904edc23689a476d", null ]
];