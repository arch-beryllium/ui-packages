var classALSAdaptor =
[
    [ "DeviceType", "classALSAdaptor.html#ac8d27aaa5def516d46bcf7298b99270a", [
      [ "DeviceUnknown", "classALSAdaptor.html#ac8d27aaa5def516d46bcf7298b99270aa5c8b7eeebb56684edd64e79a0b68c94d", null ],
      [ "RM680", "classALSAdaptor.html#ac8d27aaa5def516d46bcf7298b99270aa6b44c7c26089e10155b9fcd6ba7d549a", null ],
      [ "RM696", "classALSAdaptor.html#ac8d27aaa5def516d46bcf7298b99270aa8e00c8f35945169f59014048bf284165", null ],
      [ "NCDK", "classALSAdaptor.html#ac8d27aaa5def516d46bcf7298b99270aa47aee720954163b7245e2ba75d80bc5b", null ]
    ] ],
    [ "ALSAdaptor", "classALSAdaptor.html#a48c76e93a42d7330c3441e3d71e46878", null ],
    [ "~ALSAdaptor", "classALSAdaptor.html#afa3bd85ba5782dcd2ad95da07f5cca9b", null ],
    [ "processSample", "classALSAdaptor.html#a5c37c99a72e50b687ff85780f045dd63", null ],
    [ "resume", "classALSAdaptor.html#a53bf3fd0af96fd604ce9cdf772250a09", null ],
    [ "standby", "classALSAdaptor.html#a346b4b9553110e95caf0d5d8122519f7", null ],
    [ "startSensor", "classALSAdaptor.html#a1afb5e6319c36930a98d037f7d4a5fec", null ],
    [ "stopSensor", "classALSAdaptor.html#aab5aaf1f6ae263cd86efc1ac148894a7", null ]
];