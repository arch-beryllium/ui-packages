var classCalibrationHandler =
[
    [ "CalibrationHandler", "classCalibrationHandler.html#ad59aa26e1b9424cb08045f75c562917d", null ],
    [ "~CalibrationHandler", "classCalibrationHandler.html#a71eb87df427b0d1b98f2e4e4254809d9", null ],
    [ "initiateSession", "classCalibrationHandler.html#aee6b447d9e41a162d4d86310a1b6be77", null ],
    [ "resumeCalibration", "classCalibrationHandler.html#a29151fae7ae63483df0b592564275531", null ],
    [ "sampleReceived", "classCalibrationHandler.html#a09b55a1fec336c7b603527c314529f5c", null ],
    [ "stopCalibration", "classCalibrationHandler.html#a25e8c300d3fc49411fd5b1c1b5d2f469", null ]
];