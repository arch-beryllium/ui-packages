var classPressureSensorChannel =
[
    [ "PressureSensorChannel", "classPressureSensorChannel.html#aa9582da7017f5699db1abad242a9dd3b", null ],
    [ "~PressureSensorChannel", "classPressureSensorChannel.html#abbc59e3bec7f82d4a2d22d2bacd0b331", null ],
    [ "pressure", "classPressureSensorChannel.html#ab2e68b14c7f8f789846bee2c8895ca22", null ],
    [ "pressureChanged", "classPressureSensorChannel.html#a4b65f459b1a8dc674172b947c0571469", null ],
    [ "start", "classPressureSensorChannel.html#a134b8785d0379575e02e64f97d6b22a5", null ],
    [ "stop", "classPressureSensorChannel.html#a1369c7af1fe4bb258a96486565883d10", null ],
    [ "pressure", "classPressureSensorChannel.html#a4fa8b94edadeba8a07ce4362ee285336", null ]
];