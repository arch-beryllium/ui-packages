var classHeadingFilter =
[
    [ "HeadingFilter", "classHeadingFilter.html#a9f3e4bb239b8e831182c11c936adb71a", null ],
    [ "reset", "classHeadingFilter.html#a9060b4004c38bce52d134c64d45c6de4", null ]
];