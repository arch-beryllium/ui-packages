var dir_ade398ea461c07190715a3c582d0fb2e =
[
    [ "hybrisproximityadaptor.h", "hybrisproximityadaptor_8h.html", [
      [ "HybrisProximityAdaptor", "classHybrisProximityAdaptor.html", "classHybrisProximityAdaptor" ]
    ] ],
    [ "hybrisproximityadaptorplugin.h", "hybrisproximityadaptorplugin_8h.html", [
      [ "HybrisProximityAdaptorPlugin", "classHybrisProximityAdaptorPlugin.html", null ]
    ] ]
];