var dir_b3118ff46ea864c900ef31c2516c3653 =
[
    [ "oemtabletmagnetometeradaptor.h", "oemtabletmagnetometeradaptor_8h.html", [
      [ "OemtabletMagnetometerAdaptor", "classOemtabletMagnetometerAdaptor.html", "classOemtabletMagnetometerAdaptor" ]
    ] ],
    [ "oemtabletmagnetometeradaptorplugin.h", "oemtabletmagnetometeradaptorplugin_8h.html", [
      [ "OemtabletMagnetometerAdaptorPlugin", "classOemtabletMagnetometerAdaptorPlugin.html", null ]
    ] ]
];