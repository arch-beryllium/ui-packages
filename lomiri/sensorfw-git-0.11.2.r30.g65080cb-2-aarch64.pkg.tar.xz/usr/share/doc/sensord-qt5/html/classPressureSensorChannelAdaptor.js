var classPressureSensorChannelAdaptor =
[
    [ "PressureSensorChannelAdaptor", "classPressureSensorChannelAdaptor.html#aa1da04598c4d60155dea225ca238a8bf", null ],
    [ "pressure", "classPressureSensorChannelAdaptor.html#a95511e01e07b6d38b048c7738ba7ae5a", null ],
    [ "pressureChanged", "classPressureSensorChannelAdaptor.html#a95ea538c0cc3ef31e088d548ea749a76", null ],
    [ "pressure", "classPressureSensorChannelAdaptor.html#ab5de6c57a5793bfd030f59bcd8e035a0", null ]
];