var dir_3916de72b8b95e910c6a3b58752f61a8 =
[
    [ "compass.h", "compass_8h.html", "compass_8h" ],
    [ "datarange.h", "datarange_8h.html", "datarange_8h" ],
    [ "genericdata.h", "genericdata_8h.html", [
      [ "TimedData", "classTimedData.html", "classTimedData" ],
      [ "TimedXyzData", "classTimedXyzData.html", "classTimedXyzData" ]
    ] ],
    [ "lid.h", "lid_8h.html", "lid_8h" ],
    [ "liddata.h", "liddata_8h.html", [
      [ "LidData", "classLidData.html", "classLidData" ]
    ] ],
    [ "magneticfield.h", "magneticfield_8h.html", "magneticfield_8h" ],
    [ "moc_predefs.h", "datatypes_2moc__predefs_8h.html", "datatypes_2moc__predefs_8h" ],
    [ "orientation.h", "orientation_8h.html", "orientation_8h" ],
    [ "orientationdata.h", "orientationdata_8h.html", "orientationdata_8h" ],
    [ "posedata.h", "posedata_8h.html", [
      [ "PoseData", "classPoseData.html", "classPoseData" ]
    ] ],
    [ "proximity.h", "proximity_8h.html", "proximity_8h" ],
    [ "tap.h", "tap_8h.html", "tap_8h" ],
    [ "tapdata.h", "tapdata_8h.html", [
      [ "TapData", "classTapData.html", "classTapData" ]
    ] ],
    [ "timedunsigned.h", "timedunsigned_8h.html", [
      [ "TimedUnsigned", "classTimedUnsigned.html", "classTimedUnsigned" ]
    ] ],
    [ "touchdata.h", "touchdata_8h.html", [
      [ "TouchData", "classTouchData.html", "classTouchData" ]
    ] ],
    [ "unsigned.h", "unsigned_8h.html", "unsigned_8h" ],
    [ "utils.h", "utils_8h.html", [
      [ "Utils", "classUtils.html", null ]
    ] ],
    [ "xyz.h", "xyz_8h.html", "xyz_8h" ]
];