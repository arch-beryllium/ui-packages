var dir_3ca05558e31cc9e61f29b7b40c85a7fd =
[
    [ "humidityadaptor.h", "humidityadaptor_8h.html", [
      [ "HumidityAdaptor", "classHumidityAdaptor.html", "classHumidityAdaptor" ]
    ] ],
    [ "humidityadaptorplugin.h", "humidityadaptorplugin_8h.html", [
      [ "HumidityAdaptorPlugin", "classHumidityAdaptorPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2humidityadaptor_2moc__predefs_8h.html", "adaptors_2humidityadaptor_2moc__predefs_8h" ]
];