var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "d", "globals_d.html", null ],
    [ "g", "globals_g.html", null ],
    [ "i", "globals_i.html", null ],
    [ "l", "globals_l.html", null ],
    [ "m", "globals_m.html", null ],
    [ "o", "globals_o.html", null ],
    [ "q", "globals_q.html", null ],
    [ "s", "globals_s.html", null ],
    [ "u", "globals_u.html", null ],
    [ "x", "globals_x.html", null ],
    [ "y", "globals_y.html", null ],
    [ "z", "globals_z.html", null ]
];