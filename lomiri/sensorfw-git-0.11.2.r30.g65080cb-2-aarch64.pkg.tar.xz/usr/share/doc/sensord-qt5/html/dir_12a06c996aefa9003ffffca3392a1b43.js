var dir_12a06c996aefa9003ffffca3392a1b43 =
[
    [ "moc_predefs.h", "sensors_2rotationsensor_2moc__predefs_8h.html", "sensors_2rotationsensor_2moc__predefs_8h" ],
    [ "rotationplugin.h", "rotationplugin_8h.html", [
      [ "RotationPlugin", "classRotationPlugin.html", null ]
    ] ],
    [ "rotationsensor.h", "rotationsensor_8h.html", [
      [ "RotationSensorChannel", "classRotationSensorChannel.html", "classRotationSensorChannel" ]
    ] ],
    [ "rotationsensor_a.h", "rotationsensor__a_8h.html", [
      [ "RotationSensorChannelAdaptor", "classRotationSensorChannelAdaptor.html", "classRotationSensorChannelAdaptor" ]
    ] ]
];