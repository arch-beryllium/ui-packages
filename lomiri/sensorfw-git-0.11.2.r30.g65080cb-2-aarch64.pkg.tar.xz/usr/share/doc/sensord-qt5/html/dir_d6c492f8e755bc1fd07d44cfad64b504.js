var dir_d6c492f8e755bc1fd07d44cfad64b504 =
[
    [ "alsplugin.h", "alsplugin_8h.html", [
      [ "ALSPlugin", "classALSPlugin.html", null ]
    ] ],
    [ "alssensor.h", "alssensor_8h.html", [
      [ "ALSSensorChannel", "classALSSensorChannel.html", "classALSSensorChannel" ]
    ] ],
    [ "alssensor_a.h", "alssensor__a_8h.html", [
      [ "ALSSensorChannelAdaptor", "classALSSensorChannelAdaptor.html", "classALSSensorChannelAdaptor" ]
    ] ],
    [ "moc_predefs.h", "sensors_2alssensor_2moc__predefs_8h.html", "sensors_2alssensor_2moc__predefs_8h" ]
];