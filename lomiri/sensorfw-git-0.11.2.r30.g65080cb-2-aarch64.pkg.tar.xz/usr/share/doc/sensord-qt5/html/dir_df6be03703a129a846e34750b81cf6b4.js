var dir_df6be03703a129a846e34750b81cf6b4 =
[
    [ "magnetometeradaptor-evdevplugin.h", "magnetometeradaptor-evdevplugin_8h.html", [
      [ "MagnetometerAdaptorEvdevPlugin", "classMagnetometerAdaptorEvdevPlugin.html", null ]
    ] ],
    [ "magnetometerevdevadaptor.h", "magnetometerevdevadaptor_8h.html", [
      [ "MagAdaptorEvdev", "classMagAdaptorEvdev.html", "classMagAdaptorEvdev" ]
    ] ],
    [ "moc_predefs.h", "adaptors_2magnetometeradaptor-evdev_2moc__predefs_8h.html", "adaptors_2magnetometeradaptor-evdev_2moc__predefs_8h" ]
];