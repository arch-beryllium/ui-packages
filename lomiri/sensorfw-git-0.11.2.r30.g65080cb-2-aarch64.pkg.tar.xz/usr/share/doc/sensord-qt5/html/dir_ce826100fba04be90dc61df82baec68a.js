var dir_ce826100fba04be90dc61df82baec68a =
[
    [ "coordinatealignfilter.h", "coordinatealignfilter_8h.html", "coordinatealignfilter_8h" ],
    [ "coordinatealignfilterplugin.h", "coordinatealignfilterplugin_8h.html", [
      [ "CoordinateAlignFilterPlugin", "classCoordinateAlignFilterPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "filters_2coordinatealignfilter_2moc__predefs_8h.html", "filters_2coordinatealignfilter_2moc__predefs_8h" ]
];