var classProximitySensorChannel =
[
    [ "ProximitySensorChannel", "classProximitySensorChannel.html#abff5800c5405ecd9437fbb290a2504b3", null ],
    [ "~ProximitySensorChannel", "classProximitySensorChannel.html#a8583599a58c56d68aac9b4e23fdbc0ad", null ],
    [ "dataAvailable", "classProximitySensorChannel.html#a4362da09706e0b5f87f34d6550b15dcc", null ],
    [ "proximity", "classProximitySensorChannel.html#aa42e48155c9d6e7d0906a8258656e1b4", null ],
    [ "proximityReflectance", "classProximitySensorChannel.html#a1237d674f31262979e50d88fea330125", null ],
    [ "start", "classProximitySensorChannel.html#a1c7670c886d65eb9bdd48c69b21ab081", null ],
    [ "stop", "classProximitySensorChannel.html#a250df6ad82efab386b76894dd7fbe6a6", null ],
    [ "proximity", "classProximitySensorChannel.html#ab80da9fc19e5ef4c0dfbf36a6f36fa3c", null ],
    [ "proximityReflectance", "classProximitySensorChannel.html#a4c291239b697f02f0c505c1bfc7fa744", null ]
];