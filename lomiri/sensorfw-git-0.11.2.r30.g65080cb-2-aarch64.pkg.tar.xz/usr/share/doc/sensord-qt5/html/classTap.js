var classTap =
[
    [ "Tap", "classTap.html#adb0e494dfabe6f6842e11e96ad6bfdcf", null ],
    [ "Tap", "classTap.html#a61063591a97f4a5f3a9c1167e8b738f3", null ],
    [ "Tap", "classTap.html#a622cbeeb74518784cff1eb8dabd97e3f", null ],
    [ "direction", "classTap.html#ae71161c85e984e2d3dde377e23107278", null ],
    [ "tapData", "classTap.html#a5c4492734a025c1d3290115f2278f108", null ],
    [ "type", "classTap.html#a83f13b35ac7118dbf49e8959da52e2fc", null ],
    [ "operator>>", "classTap.html#a9bd3ff9be0533899442dced26d7dc665", null ],
    [ "direction", "classTap.html#a0d18cc6a45902836602229967623dd38", null ],
    [ "type", "classTap.html#a24ef74462c07cb85987e59196cf7cf3a", null ]
];