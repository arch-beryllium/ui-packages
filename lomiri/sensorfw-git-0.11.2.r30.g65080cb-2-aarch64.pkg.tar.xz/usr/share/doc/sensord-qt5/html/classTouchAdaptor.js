var classTouchAdaptor =
[
    [ "TouchAdaptor", "classTouchAdaptor.html#ab197bfb3d0dc7aec3ae4b1c9645afc78", null ],
    [ "~TouchAdaptor", "classTouchAdaptor.html#ac8b768d7978b5419d9afb507386b3601", null ]
];