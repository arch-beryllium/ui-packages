var dir_eccfd749a445dab872cccbf256133ada =
[
    [ "moc_predefs.h", "adaptors_2oemtabletaccelerometer_2moc__predefs_8h.html", "adaptors_2oemtabletaccelerometer_2moc__predefs_8h" ],
    [ "oemtabletaccelerometeradaptor.h", "oemtabletaccelerometeradaptor_8h.html", [
      [ "OemtabletAccelAdaptor", "classOemtabletAccelAdaptor.html", "classOemtabletAccelAdaptor" ]
    ] ],
    [ "oemtabletaccelerometeradaptorplugin.h", "oemtabletaccelerometeradaptorplugin_8h.html", [
      [ "OemtabletAccelerometerAdaptorPlugin", "classOemtabletAccelerometerAdaptorPlugin.html", null ]
    ] ]
];