var classDataRange =
[
    [ "DataRange", "classDataRange.html#aea6cc654ec9dfeb926ca7f212a7b8d06", null ],
    [ "DataRange", "classDataRange.html#a3f93d321323d9114807daa288d2dd61e", null ],
    [ "DataRange", "classDataRange.html#aa298f00e15ac70170db706049598f248", null ],
    [ "operator=", "classDataRange.html#ab5ce2dc91a3f02c2f66be469bf7bd8b8", null ],
    [ "operator==", "classDataRange.html#a1fe839c47df7a881202888003012da94", null ],
    [ "max", "classDataRange.html#a51bfddffbd3f325cb9f313a1d81a353c", null ],
    [ "min", "classDataRange.html#a2102c85bb7b0251e328748b1a196208d", null ],
    [ "resolution", "classDataRange.html#a9dd7b31cdefe87427fc40ce1182ae7d2", null ]
];