var classMagnetometerAdaptorAscii =
[
    [ "MagnetometerAdaptorAscii", "classMagnetometerAdaptorAscii.html#aaa251e7191e501556c38632c4ee2efc0", null ],
    [ "~MagnetometerAdaptorAscii", "classMagnetometerAdaptorAscii.html#aed2217232f1a6c73bc255fc72d908bed", null ]
];