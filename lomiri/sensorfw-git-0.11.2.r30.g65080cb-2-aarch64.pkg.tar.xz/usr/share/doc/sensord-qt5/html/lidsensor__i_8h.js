var lidsensor__i_8h =
[
    [ "LidSensorChannelInterface", "classLidSensorChannelInterface.html", "classLidSensorChannelInterface" ],
    [ "LidSensor", "lidsensor__i_8h.html#ada7ab5657ac153ed8ef7f76395515a7c", null ]
];