var coordinatealignfilter_8h =
[
    [ "TMatrix", "classTMatrix.html", "classTMatrix" ],
    [ "CoordinateAlignFilter", "classCoordinateAlignFilter.html", "classCoordinateAlignFilter" ],
    [ "Q_DECLARE_METATYPE", "coordinatealignfilter_8h.html#aa1caaec3c9052ac1ce2719f4bee9025f", null ]
];