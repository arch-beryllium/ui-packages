var classTapSensorChannelInterface =
[
    [ "TapSelection", "classTapSensorChannelInterface.html#afd5d3580ebeedf766eab0fd8dc80085e", [
      [ "Single", "classTapSensorChannelInterface.html#afd5d3580ebeedf766eab0fd8dc80085ea0f52aed78919ce978fff653705fb896e", null ],
      [ "Double", "classTapSensorChannelInterface.html#afd5d3580ebeedf766eab0fd8dc80085ea55335601c1a5740098c0badb33b19d5e", null ],
      [ "SingleDouble", "classTapSensorChannelInterface.html#afd5d3580ebeedf766eab0fd8dc80085eadaf70e72700a48ca6681b7a0f5e8e8c9", null ]
    ] ],
    [ "TapSensorChannelInterface", "classTapSensorChannelInterface.html#a07789fc3d4c66e5f9dca8285ab919a8c", null ],
    [ "dataAvailable", "classTapSensorChannelInterface.html#a1caf988c0f99646aa5097b3308fbcc86", null ],
    [ "dataReceivedImpl", "classTapSensorChannelInterface.html#a2f925890bcc4891c70d196180a29c573", null ],
    [ "getTapType", "classTapSensorChannelInterface.html#afa8a6ec10a5a7851e631a62a4157c997", null ],
    [ "setTapType", "classTapSensorChannelInterface.html#aff180353e8601b5f22b6915a8dd51291", null ]
];