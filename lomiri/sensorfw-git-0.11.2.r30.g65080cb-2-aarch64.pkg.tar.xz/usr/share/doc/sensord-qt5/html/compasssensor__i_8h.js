var compasssensor__i_8h =
[
    [ "CompassSensorChannelInterface", "classCompassSensorChannelInterface.html", "classCompassSensorChannelInterface" ],
    [ "CompassSensor", "compasssensor__i_8h.html#aa09631bbee18c70c9359c44184af3c15", null ]
];