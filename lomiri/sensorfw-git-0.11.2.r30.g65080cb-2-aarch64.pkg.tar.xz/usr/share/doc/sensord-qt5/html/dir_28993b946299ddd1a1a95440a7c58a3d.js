var dir_28993b946299ddd1a1a95440a7c58a3d =
[
    [ "lidplugin.h", "lidplugin_8h.html", [
      [ "LidPlugin", "classLidPlugin.html", null ]
    ] ],
    [ "lidsensor.h", "lidsensor_8h.html", [
      [ "LidSensorChannel", "classLidSensorChannel.html", "classLidSensorChannel" ]
    ] ],
    [ "lidsensor_a.h", "lidsensor__a_8h.html", [
      [ "LidSensorChannelAdaptor", "classLidSensorChannelAdaptor.html", "classLidSensorChannelAdaptor" ]
    ] ],
    [ "moc_predefs.h", "sensors_2lidsensor_2moc__predefs_8h.html", "sensors_2lidsensor_2moc__predefs_8h" ]
];