var classALSSensorChannelAdaptor =
[
    [ "ALSSensorChannelAdaptor", "classALSSensorChannelAdaptor.html#ae6aefd01f98e712195728f63fd183cab", null ],
    [ "ALSChanged", "classALSSensorChannelAdaptor.html#a4885e729e11ff9f89da5dbda538425d3", null ],
    [ "lux", "classALSSensorChannelAdaptor.html#ace7e4f5bd4449ad1b0d09845fe3505db", null ],
    [ "lux", "classALSSensorChannelAdaptor.html#ae5e6a6bd6f31ddb0909f65fd47763c7d", null ]
];