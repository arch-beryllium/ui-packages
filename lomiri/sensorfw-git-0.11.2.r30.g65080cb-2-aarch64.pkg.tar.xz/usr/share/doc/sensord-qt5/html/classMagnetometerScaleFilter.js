var classMagnetometerScaleFilter =
[
    [ "MagnetometerScaleFilter", "classMagnetometerScaleFilter.html#a78c12d1c313d27389220472be727f85f", null ]
];