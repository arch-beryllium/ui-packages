var classHybrisOrientationAdaptor =
[
    [ "HybrisOrientationAdaptor", "classHybrisOrientationAdaptor.html#a4e5fba7846e5b8339172058c747fb400", null ],
    [ "~HybrisOrientationAdaptor", "classHybrisOrientationAdaptor.html#ae186d98ad40c7bddb3fd9a545049a980", null ],
    [ "init", "classHybrisOrientationAdaptor.html#a79b7290fa9eae97eb321365086cc4d07", null ],
    [ "processSample", "classHybrisOrientationAdaptor.html#aa8de25ea02d57351d5d4891d48f8bf9e", null ],
    [ "startSensor", "classHybrisOrientationAdaptor.html#a31432f0968ce48378f219640c4d73c30", null ],
    [ "stopSensor", "classHybrisOrientationAdaptor.html#a8da7acb5d0e89b65876c9591ba0b1532", null ]
];