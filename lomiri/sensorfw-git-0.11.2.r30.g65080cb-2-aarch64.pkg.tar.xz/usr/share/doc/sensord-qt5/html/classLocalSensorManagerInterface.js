var classLocalSensorManagerInterface =
[
    [ "~LocalSensorManagerInterface", "classLocalSensorManagerInterface.html#aa32b30c9593336d59e3e1aefd5af61fe", null ],
    [ "LocalSensorManagerInterface", "classLocalSensorManagerInterface.html#a41f8e5bba3be7d19cd8875c276be4846", null ],
    [ "errorCode", "classLocalSensorManagerInterface.html#a6788ef4cf4efd2b446e5a8a6e52bffa8", null ],
    [ "errorSignal", "classLocalSensorManagerInterface.html#aaa3ad9f1af8ba6c12429894563597c66", null ],
    [ "errorString", "classLocalSensorManagerInterface.html#ab624a8b65aab32d6f1357492d75af470", null ],
    [ "loadPlugin", "classLocalSensorManagerInterface.html#ae73b4af7fe297fbcd88cb4f89ee5ca18", null ],
    [ "loadPluginFinished", "classLocalSensorManagerInterface.html#ab728ea429f71b1c0823a52e6e4cd271f", null ],
    [ "loadPluginFinished", "classLocalSensorManagerInterface.html#a3b57f19ac29a70ffcdeab46d48b97fea", null ],
    [ "releaseSensor", "classLocalSensorManagerInterface.html#a6be3846f03348cf16bf2af13788072a6", null ],
    [ "releaseSensorFinished", "classLocalSensorManagerInterface.html#ada3e41485022eef71537f5dc8be2538f", null ],
    [ "releaseSensorFinished", "classLocalSensorManagerInterface.html#a6e3d2b6276bbf1d41e163f6db9dc958e", null ],
    [ "requestSensor", "classLocalSensorManagerInterface.html#a29d33e818111c2cd151482b41538ed1c", null ],
    [ "requestSensorFinished", "classLocalSensorManagerInterface.html#af4dad672c0f500044704aaa7c8c69fef", null ],
    [ "requestSensorFinished", "classLocalSensorManagerInterface.html#af7401272cf4ad0f354dc07acf2caa530", null ],
    [ "errorCode", "classLocalSensorManagerInterface.html#aae20874b244ec46a364ef7f6673cf541", null ],
    [ "errorCodeInt", "classLocalSensorManagerInterface.html#acc49c406486b33bd0cce01f689b9ecb6", null ],
    [ "errorString", "classLocalSensorManagerInterface.html#aa1573af3204128efebc71bb47da7891b", null ]
];