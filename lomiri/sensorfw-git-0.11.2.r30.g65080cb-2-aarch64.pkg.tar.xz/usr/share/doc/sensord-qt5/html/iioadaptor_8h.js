var iioadaptor_8h =
[
    [ "IioAdaptor", "classIioAdaptor.html", "classIioAdaptor" ],
    [ "IIO_BUFFER_LEN", "iioadaptor_8h.html#a37dec95f45523a8153cc79cf59b0bae4", null ],
    [ "IIO_MAX_DEVICE_CHANNELS", "iioadaptor_8h.html#a0419051181c63080338472f1b32a5171", null ]
];