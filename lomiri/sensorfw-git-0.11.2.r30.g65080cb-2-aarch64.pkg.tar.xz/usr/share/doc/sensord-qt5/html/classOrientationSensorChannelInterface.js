var classOrientationSensorChannelInterface =
[
    [ "OrientationSensorChannelInterface", "classOrientationSensorChannelInterface.html#aa02d970cc84bc5ef51fa2b388880b9cd", null ],
    [ "dataReceivedImpl", "classOrientationSensorChannelInterface.html#a3c596e15b51590e6ef46a39f73936d90", null ],
    [ "orientation", "classOrientationSensorChannelInterface.html#a21c94978d819c7eb37ed106c1ef9535f", null ],
    [ "orientationChanged", "classOrientationSensorChannelInterface.html#aa769e2bffcf370cf0574cb1991650d8c", null ],
    [ "setThreshold", "classOrientationSensorChannelInterface.html#a26070c0ebcebaaedf121b82ad7239196", null ],
    [ "threshold", "classOrientationSensorChannelInterface.html#ac751fe0678ea2a13bbba94ad6dc553ec", null ],
    [ "orientation", "classOrientationSensorChannelInterface.html#a496676486bba512333b8f9ac2ebc387a", null ],
    [ "threshold", "classOrientationSensorChannelInterface.html#ae05b8235728cf72833dbf7b527cd4da6", null ]
];