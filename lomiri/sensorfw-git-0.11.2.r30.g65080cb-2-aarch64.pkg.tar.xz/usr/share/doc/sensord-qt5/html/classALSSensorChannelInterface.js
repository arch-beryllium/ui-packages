var classALSSensorChannelInterface =
[
    [ "ALSSensorChannelInterface", "classALSSensorChannelInterface.html#abb82d09ff748a082ad49d58e7320200a", null ],
    [ "ALSChanged", "classALSSensorChannelInterface.html#a98fe25e400a913618cf95d36e5e3610c", null ],
    [ "dataReceivedImpl", "classALSSensorChannelInterface.html#ac0a33f992fdc056009c1ee0dd86b3198", null ],
    [ "lux", "classALSSensorChannelInterface.html#a3ee9e1440530615fadf8024e0d28a829", null ],
    [ "lux", "classALSSensorChannelInterface.html#a2ec465450656ac989bf5df7adcd4001d", null ]
];