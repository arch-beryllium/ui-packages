var classAccelerometerSensorChannel =
[
    [ "AccelerometerSensorChannel", "classAccelerometerSensorChannel.html#ab93cf6b041ac6b8f13b703ece8fc2773", null ],
    [ "~AccelerometerSensorChannel", "classAccelerometerSensorChannel.html#a1cb78ad7b693f2d83d1714e601dd919e", null ],
    [ "dataAvailable", "classAccelerometerSensorChannel.html#a9a7c615c5940a25a4f3f6ee222d62623", null ],
    [ "downsamplingSupported", "classAccelerometerSensorChannel.html#aaf0c24dca991df48b8ce30bb33bf730c", null ],
    [ "get", "classAccelerometerSensorChannel.html#ac6f64c31f8c1e0803772d0e62ca07801", null ],
    [ "removeSession", "classAccelerometerSensorChannel.html#a95c064e1814fb7ed56a4e3aee6935058", null ],
    [ "start", "classAccelerometerSensorChannel.html#a5afc69aa341bff26e5f19659db533b7e", null ],
    [ "stop", "classAccelerometerSensorChannel.html#a722e68e52dd8ecaf8c763f16af277717", null ],
    [ "value", "classAccelerometerSensorChannel.html#a133d08c01ac2673908b670e28327d39e", null ]
];