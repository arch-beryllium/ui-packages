var classSteAccelAdaptor =
[
    [ "SteAccelAdaptor", "classSteAccelAdaptor.html#a1905390c88344f19be1ec5ccb770af33", null ],
    [ "~SteAccelAdaptor", "classSteAccelAdaptor.html#a622f559764d45d7923cbbfc74ef84fc9", null ],
    [ "processSample", "classSteAccelAdaptor.html#a292bdf9edce4925f03e8c23497b19e68", null ],
    [ "setStandbyOverride", "classSteAccelAdaptor.html#a618352f78f2810bad2b66cc500d05727", null ],
    [ "startSensor", "classSteAccelAdaptor.html#a30c80ac2b978413a84c9f8c4d411de58", null ],
    [ "stopSensor", "classSteAccelAdaptor.html#ad0f96bff3b608e68e2cf307ae33060db", null ]
];