var classIntervalRequest =
[
    [ "IntervalRequest", "classIntervalRequest.html#a0ae576c4b60878d8e13cab8ce9cde906", null ],
    [ "operator==", "classIntervalRequest.html#a560b04675161d04075050068558511ea", null ],
    [ "id", "classIntervalRequest.html#a9f7b77d88b045045b2c3b91156eab300", null ],
    [ "value", "classIntervalRequest.html#ac791ac59ae8d0edfcda2f4372b70f9d1", null ]
];