var classTapData =
[
    [ "Direction", "classTapData.html#af9293760c649e894accc9135fad0b7c1", [
      [ "X", "classTapData.html#af9293760c649e894accc9135fad0b7c1aa3e4e6625252b9385b59d5dd9c76745d", null ],
      [ "Y", "classTapData.html#af9293760c649e894accc9135fad0b7c1a51f23fe8ee265491fb5092a2ca1293d9", null ],
      [ "Z", "classTapData.html#af9293760c649e894accc9135fad0b7c1af12c6f681e2e4a18173d9b40bb5f63c8", null ],
      [ "LeftRight", "classTapData.html#af9293760c649e894accc9135fad0b7c1a6275a47c97948ff369e284b2699a7793", null ],
      [ "RightLeft", "classTapData.html#af9293760c649e894accc9135fad0b7c1a499b67fcedff78b8de9a9e6e89528d09", null ],
      [ "TopBottom", "classTapData.html#af9293760c649e894accc9135fad0b7c1a83c753c9b38d0b96be3a6ce4f81bca94", null ],
      [ "BottomTop", "classTapData.html#af9293760c649e894accc9135fad0b7c1a03948e346cac79a451043098333809d0", null ],
      [ "FaceBack", "classTapData.html#af9293760c649e894accc9135fad0b7c1aeb600a1f642accf20a780a6585ab1c34", null ],
      [ "BackFace", "classTapData.html#af9293760c649e894accc9135fad0b7c1a7e27e7c50071dcbc986f6c82ebfcd4c0", null ]
    ] ],
    [ "Type", "classTapData.html#abaedea392d7739013541db0613dd7505", [
      [ "DoubleTap", "classTapData.html#abaedea392d7739013541db0613dd7505af994e6390c565d36a0b4f484a68bf051", null ],
      [ "SingleTap", "classTapData.html#abaedea392d7739013541db0613dd7505a09e83825d246f9e4025a58eb19f85b9d", null ]
    ] ],
    [ "TapData", "classTapData.html#a0c1e8ef7f0035053d007286487ccb9bb", null ],
    [ "TapData", "classTapData.html#ae7c1828a24c1744eeb4dd21497215a4d", null ],
    [ "direction_", "classTapData.html#abf7126dded6962e93f1ab0bf0bf86def", null ],
    [ "type_", "classTapData.html#afb204735d4b7496aa1a7b2e15f055187", null ]
];