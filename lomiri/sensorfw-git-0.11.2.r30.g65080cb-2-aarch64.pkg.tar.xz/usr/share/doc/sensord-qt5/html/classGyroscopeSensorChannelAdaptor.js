var classGyroscopeSensorChannelAdaptor =
[
    [ "GyroscopeSensorChannelAdaptor", "classGyroscopeSensorChannelAdaptor.html#af858c919fe8d57541968e895c8d02129", null ],
    [ "dataAvailable", "classGyroscopeSensorChannelAdaptor.html#a046118ad670b0e9d4bba8960ccfc7401", null ],
    [ "value", "classGyroscopeSensorChannelAdaptor.html#ac3b2aa197e107f0394eab0877ffb5e8d", null ],
    [ "value", "classGyroscopeSensorChannelAdaptor.html#a9e69061bf2041acc93ef04a8fc3df368", null ]
];