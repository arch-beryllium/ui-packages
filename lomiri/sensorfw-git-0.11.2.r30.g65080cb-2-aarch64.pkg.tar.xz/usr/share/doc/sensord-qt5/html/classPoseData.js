var classPoseData =
[
    [ "Orientation", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9", [
      [ "Undefined", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9a556ead348d2cde618316043febfc119f", null ],
      [ "LeftUp", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9a6f7f5fab6012f5b08af0f4219fb3b919", null ],
      [ "RightUp", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9a4a2289eb2841c82f07d1f6695f6f642f", null ],
      [ "BottomUp", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9a9bd7f7d81f3820ec7c58d7f39757c393", null ],
      [ "BottomDown", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9acb47cbf678c6c812f7e8e56c6af8643f", null ],
      [ "FaceDown", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9a1c11b6dcdbb91ad023ab2dbd18c29011", null ],
      [ "FaceUp", "classPoseData.html#aca17074241c49179bb75b373ab32c9b9a517d762ec37c6c850f8b2959bdfc3882", null ]
    ] ],
    [ "PoseData", "classPoseData.html#a98b4b7392f59c9c83152f701440091b2", null ],
    [ "PoseData", "classPoseData.html#a1c362f207d17fd00c32bd419767c5c5a", null ],
    [ "PoseData", "classPoseData.html#adbd6d607e198c22c658ecd93b2eec7db", null ],
    [ "orientation_", "classPoseData.html#a87ad024551afddf0617e65fdc968829d", null ]
];