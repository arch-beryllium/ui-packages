var classAccelerometerSensorChannelAdaptor =
[
    [ "AccelerometerSensorChannelAdaptor", "classAccelerometerSensorChannelAdaptor.html#a20c4525da4b72b2cd6fa8fa95046d05c", null ],
    [ "dataAvailable", "classAccelerometerSensorChannelAdaptor.html#aea9d3ceb869e074505174dde8abbc58a", null ],
    [ "xyz", "classAccelerometerSensorChannelAdaptor.html#ab85168bbdb5b8b06bebfb70543278e73", null ],
    [ "xyz", "classAccelerometerSensorChannelAdaptor.html#ad25dc30128870c01d22d2d951c38fde5", null ]
];