var classCompassSensorChannel =
[
    [ "CompassSensorChannel", "classCompassSensorChannel.html#af83dcd6d5812c2efdd80b14851b956de", null ],
    [ "~CompassSensorChannel", "classCompassSensorChannel.html#abdf2a2503ab5cbb5cecb4a5d7989a6c3", null ],
    [ "dataAvailable", "classCompassSensorChannel.html#a9a18dc057177b4c60206e2f9ae30ac9a", null ],
    [ "declinationValue", "classCompassSensorChannel.html#a0601557859e9479f5254a1f6fa7bd47c", null ],
    [ "get", "classCompassSensorChannel.html#aa924ca4e30bfd97e8d1a59863bcf0d25", null ],
    [ "start", "classCompassSensorChannel.html#a0e84ebc5fe89845c4585db43fc500df1", null ],
    [ "stop", "classCompassSensorChannel.html#af68e51b1ff611e6a839f592cc83bcfef", null ],
    [ "declinationvalue", "classCompassSensorChannel.html#a01a2a93749c434c386549c76736faeab", null ],
    [ "value", "classCompassSensorChannel.html#ad7b419e3513a6de9d2b1282ea18ad930", null ]
];