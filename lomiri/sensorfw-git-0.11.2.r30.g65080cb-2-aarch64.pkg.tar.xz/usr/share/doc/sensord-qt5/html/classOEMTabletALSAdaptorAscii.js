var classOEMTabletALSAdaptorAscii =
[
    [ "OEMTabletALSAdaptorAscii", "classOEMTabletALSAdaptorAscii.html#aa58d3cebd479459b21057eacac8d3814", null ],
    [ "~OEMTabletALSAdaptorAscii", "classOEMTabletALSAdaptorAscii.html#a92b83b779401daa87d1c0d4401ef5920", null ],
    [ "setStandbyOverride", "classOEMTabletALSAdaptorAscii.html#a4dfcad0b6582328aec7d4afa4e42eeba", null ]
];