var dir_168c2c9e2cecc8aab9287db370b04f5a =
[
    [ "moc_predefs.h", "adaptors_2oaktrailaccelerometer_2moc__predefs_8h.html", "adaptors_2oaktrailaccelerometer_2moc__predefs_8h" ],
    [ "oaktrailaccelerometeradaptor.h", "oaktrailaccelerometeradaptor_8h.html", [
      [ "OaktrailAccelAdaptor", "classOaktrailAccelAdaptor.html", "classOaktrailAccelAdaptor" ]
    ] ],
    [ "oaktrailaccelerometeradaptorplugin.h", "oaktrailaccelerometeradaptorplugin_8h.html", [
      [ "OaktrailAccelerometerAdaptorPlugin", "classOaktrailAccelerometerAdaptorPlugin.html", null ]
    ] ]
];