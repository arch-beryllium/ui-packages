var classXYZ =
[
    [ "XYZ", "classXYZ.html#afa55cea1b74cbc9ca9615432f8d744db", null ],
    [ "XYZ", "classXYZ.html#aaee56a589f4a3dd1d585767f7ba68cac", null ],
    [ "XYZ", "classXYZ.html#a8a6ea61ccc8f012d223f0e69997cf16d", null ],
    [ "operator=", "classXYZ.html#a513a82a863f1a09640973f1c4a277518", null ],
    [ "operator==", "classXYZ.html#a617591de7a90abbcb72d47c47ea95c66", null ],
    [ "x", "classXYZ.html#a9ec58b494374e8db190bf50b9edda7c6", null ],
    [ "XYZData", "classXYZ.html#a15bd7563a4ca0234d4f85b56a7658a36", null ],
    [ "y", "classXYZ.html#a9d4f8b342e6b771b41d1b5bd28a900b8", null ],
    [ "z", "classXYZ.html#a4d918cb81c9a929ababe84ea1b54d677", null ],
    [ "operator>>", "classXYZ.html#a20f90756727aa7cdb7905a1406fca8d5", null ],
    [ "x", "classXYZ.html#aa527dbf85a9515cbd5760da19150c75e", null ],
    [ "y", "classXYZ.html#a1762dab6d79beeb3820cc4b66d279744", null ],
    [ "z", "classXYZ.html#ac0c7b3a10a3d80e8852525fbe9600b59", null ]
];