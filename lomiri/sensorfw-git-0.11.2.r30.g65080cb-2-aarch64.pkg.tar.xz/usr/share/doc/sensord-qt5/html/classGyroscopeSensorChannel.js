var classGyroscopeSensorChannel =
[
    [ "GyroscopeSensorChannel", "classGyroscopeSensorChannel.html#ae6e334070c399c05639463c1c8a7c8fc", null ],
    [ "~GyroscopeSensorChannel", "classGyroscopeSensorChannel.html#a616a1bd511d00c91e1d2edbb2092ef8f", null ],
    [ "dataAvailable", "classGyroscopeSensorChannel.html#ad973839c5eb2bc33683a818e87df15ba", null ],
    [ "get", "classGyroscopeSensorChannel.html#a703d1ecb0e262e163a9980511a6aa6e5", null ],
    [ "start", "classGyroscopeSensorChannel.html#a61098e4888254ea054beb933c87c4be2", null ],
    [ "stop", "classGyroscopeSensorChannel.html#ae4f38bc288e6f5bcc33e84701171cd05", null ],
    [ "value", "classGyroscopeSensorChannel.html#a36aa270131c00195c0f3701961c7ad09", null ]
];