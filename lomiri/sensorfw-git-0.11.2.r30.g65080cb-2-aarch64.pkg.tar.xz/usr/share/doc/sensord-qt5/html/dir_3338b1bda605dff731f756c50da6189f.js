var dir_3338b1bda605dff731f756c50da6189f =
[
    [ "magcoordinatealignfilter.h", "magcoordinatealignfilter_8h.html", [
      [ "TMagMatrix", "classTMagMatrix.html", "classTMagMatrix" ],
      [ "MagCoordinateAlignFilter", "classMagCoordinateAlignFilter.html", "classMagCoordinateAlignFilter" ]
    ] ],
    [ "magcoordinatealignfilterplugin.h", "magcoordinatealignfilterplugin_8h.html", [
      [ "MagCoordinateAlignFilterPlugin", "classMagCoordinateAlignFilterPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "filters_2magcoordinatealignfilter_2moc__predefs_8h.html", "filters_2magcoordinatealignfilter_2moc__predefs_8h" ]
];