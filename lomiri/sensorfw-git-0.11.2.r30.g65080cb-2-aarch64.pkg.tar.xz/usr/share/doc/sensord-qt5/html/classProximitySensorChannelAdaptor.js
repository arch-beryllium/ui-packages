var classProximitySensorChannelAdaptor =
[
    [ "ProximitySensorChannelAdaptor", "classProximitySensorChannelAdaptor.html#a3a5ce4787c8037ab79a4c43065eaab10", null ],
    [ "dataAvailable", "classProximitySensorChannelAdaptor.html#ad32cef34cb534c6515e0efa7b5c16eb7", null ],
    [ "proximity", "classProximitySensorChannelAdaptor.html#abbc53afd5ddc216088ee58cb655739d4", null ],
    [ "proximityReflectance", "classProximitySensorChannelAdaptor.html#a1706e3c6ab501b7bbce194f23398e02e", null ],
    [ "proximity", "classProximitySensorChannelAdaptor.html#ada7a6a5516bc9ed6f7084e92403430c7", null ],
    [ "proximityReflectance", "classProximitySensorChannelAdaptor.html#a27a1a19f26a1de17a0dac8b1d974eb23", null ]
];