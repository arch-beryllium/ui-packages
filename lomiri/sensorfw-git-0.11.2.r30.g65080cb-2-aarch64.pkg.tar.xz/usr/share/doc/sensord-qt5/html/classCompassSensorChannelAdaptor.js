var classCompassSensorChannelAdaptor =
[
    [ "CompassSensorChannelAdaptor", "classCompassSensorChannelAdaptor.html#a8c846e3802d1b3ccd2651aa869dcb616", null ],
    [ "dataAvailable", "classCompassSensorChannelAdaptor.html#a6deb1af5258f5e327c5973d23d1c9f56", null ],
    [ "declinationValue", "classCompassSensorChannelAdaptor.html#a762bef4b21388aa830f39bcc20e06fa9", null ],
    [ "value", "classCompassSensorChannelAdaptor.html#af0ccc37281a89a7fa972ebac9e50d926", null ],
    [ "declinationValue", "classCompassSensorChannelAdaptor.html#ada32518f71a3d7fcf31cdb016e5a8b3e", null ],
    [ "value", "classCompassSensorChannelAdaptor.html#a519818a7e47e01429ba88ac896a0d5a6", null ]
];