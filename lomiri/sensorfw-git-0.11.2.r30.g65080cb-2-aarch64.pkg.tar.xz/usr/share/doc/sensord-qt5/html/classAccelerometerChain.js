var classAccelerometerChain =
[
    [ "AccelerometerChain", "classAccelerometerChain.html#aee5cab1f74ceb7e69c0ac467bf0ad6e0", null ],
    [ "~AccelerometerChain", "classAccelerometerChain.html#a31fbc84ef5d505815a391727cf817035", null ],
    [ "start", "classAccelerometerChain.html#a6d9fa621ec5d7525e7912e4ebd39304e", null ],
    [ "stop", "classAccelerometerChain.html#a2f3b85d998f1e1924bd1de5671cb6f8e", null ]
];