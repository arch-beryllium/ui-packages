var classTapAdaptor =
[
    [ "TapAdaptor", "classTapAdaptor.html#ab653004b4c932454e6fb562ce4877d86", null ],
    [ "~TapAdaptor", "classTapAdaptor.html#a7f0adebf7729d61f85df12c336e07fb1", null ],
    [ "setInterval", "classTapAdaptor.html#a06d23a52ceaafa95d4a83321b7a44039", null ]
];