var dir_57dcfc933c0aca7aec2c190eaca483ef =
[
    [ "compasschain.h", "compasschain_8h.html", [
      [ "CompassChain", "classCompassChain.html", "classCompassChain" ]
    ] ],
    [ "compasschainplugin.h", "compasschainplugin_8h.html", [
      [ "CompassChainPlugin", "classCompassChainPlugin.html", null ]
    ] ],
    [ "compassfilter.h", "compassfilter_8h.html", [
      [ "CompassFilter", "classCompassFilter.html", "classCompassFilter" ]
    ] ],
    [ "moc_predefs.h", "chains_2compasschain_2moc__predefs_8h.html", "chains_2compasschain_2moc__predefs_8h" ],
    [ "orientationfilter.h", "orientationfilter_8h.html", [
      [ "OrientationFilter", "classOrientationFilter.html", "classOrientationFilter" ]
    ] ]
];