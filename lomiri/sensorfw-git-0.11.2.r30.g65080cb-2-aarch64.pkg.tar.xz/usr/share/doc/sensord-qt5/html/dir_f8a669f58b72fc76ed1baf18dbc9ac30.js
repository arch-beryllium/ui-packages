var dir_f8a669f58b72fc76ed1baf18dbc9ac30 =
[
    [ "downsamplefilter.h", "downsamplefilter_8h.html", [
      [ "DownsampleFilter", "classDownsampleFilter.html", "classDownsampleFilter" ]
    ] ],
    [ "downsamplefilterplugin.h", "downsamplefilterplugin_8h.html", [
      [ "DownsampleFilterPlugin", "classDownsampleFilterPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "filters_2downsamplefilter_2moc__predefs_8h.html", "filters_2downsamplefilter_2moc__predefs_8h" ]
];