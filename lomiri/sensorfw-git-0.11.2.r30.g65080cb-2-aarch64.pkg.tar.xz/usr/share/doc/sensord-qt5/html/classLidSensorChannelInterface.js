var classLidSensorChannelInterface =
[
    [ "LidSensorChannelInterface", "classLidSensorChannelInterface.html#ab8772baf9d7193cdb95ff12437afcbd9", null ],
    [ "closed", "classLidSensorChannelInterface.html#a120769374a7ff19211058fe0615e9d73", null ],
    [ "dataReceivedImpl", "classLidSensorChannelInterface.html#ae28daf18ecf802eeb99e2eff65bf7d94", null ],
    [ "lidChanged", "classLidSensorChannelInterface.html#a8a647f67aa7cfe1a68c44235eaf8cb08", null ],
    [ "closed", "classLidSensorChannelInterface.html#a2798ccb640617304b2826bbdd381f022", null ]
];