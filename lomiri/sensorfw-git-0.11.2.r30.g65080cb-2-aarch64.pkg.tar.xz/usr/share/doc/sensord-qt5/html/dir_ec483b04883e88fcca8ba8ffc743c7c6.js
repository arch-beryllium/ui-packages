var dir_ec483b04883e88fcca8ba8ffc743c7c6 =
[
    [ "hybrisaccelerometeradaptor.h", "hybrisaccelerometeradaptor_8h.html", [
      [ "HybrisAccelerometerAdaptor", "classHybrisAccelerometerAdaptor.html", "classHybrisAccelerometerAdaptor" ]
    ] ],
    [ "hybrisaccelerometeradaptorplugin.h", "hybrisaccelerometeradaptorplugin_8h.html", [
      [ "HybrisAccelerometerAdaptorPlugin", "classHybrisAccelerometerAdaptorPlugin.html", null ]
    ] ]
];