var dir_a5ee243c074493c100fb6ab825d09b10 =
[
    [ "magnetometeradaptor-ncdk.h", "magnetometeradaptor-ncdk_8h.html", [
      [ "MagnetometerAdaptorNCDK", "classMagnetometerAdaptorNCDK.html", "classMagnetometerAdaptorNCDK" ]
    ] ],
    [ "magnetometeradaptorplugin-ncdk.h", "magnetometeradaptorplugin-ncdk_8h.html", [
      [ "MagnetometerAdaptorPluginNCDK", "classMagnetometerAdaptorPluginNCDK.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2magnetometeradaptor-ncdk_2moc__predefs_8h.html", "adaptors_2magnetometeradaptor-ncdk_2moc__predefs_8h" ]
];