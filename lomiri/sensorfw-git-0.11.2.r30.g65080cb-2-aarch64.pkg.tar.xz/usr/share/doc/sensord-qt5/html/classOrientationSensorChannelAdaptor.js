var classOrientationSensorChannelAdaptor =
[
    [ "OrientationSensorChannelAdaptor", "classOrientationSensorChannelAdaptor.html#a9bbc9ef38471402059dc15a871ca44a1", null ],
    [ "orientation", "classOrientationSensorChannelAdaptor.html#a28941ca3beccf77212e0b0bd0339d2a4", null ],
    [ "orientationChanged", "classOrientationSensorChannelAdaptor.html#aa5b6bc120e9b2648a35e8a2f988d0d0f", null ],
    [ "setThreshold", "classOrientationSensorChannelAdaptor.html#a887e1c618bd7c168cbc15944570d2084", null ],
    [ "threshold", "classOrientationSensorChannelAdaptor.html#a8eb2e7f7e36a3b42637e0fbbc740814e", null ],
    [ "orientation", "classOrientationSensorChannelAdaptor.html#a5427de37701590f7e298797b4680f154", null ],
    [ "threshold", "classOrientationSensorChannelAdaptor.html#a80533135c0a1fdb8fb8b8e3ae3ea7485", null ]
];