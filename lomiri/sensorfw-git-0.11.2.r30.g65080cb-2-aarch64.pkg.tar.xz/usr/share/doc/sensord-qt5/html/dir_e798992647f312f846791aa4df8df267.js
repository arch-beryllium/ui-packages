var dir_e798992647f312f846791aa4df8df267 =
[
    [ "moc_predefs.h", "adaptors_2proximityadaptor_2moc__predefs_8h.html", "adaptors_2proximityadaptor_2moc__predefs_8h" ],
    [ "proximityadaptor.h", "proximityadaptor_8h.html", [
      [ "ProximityAdaptor", "classProximityAdaptor.html", "classProximityAdaptor" ]
    ] ],
    [ "proximityadaptorplugin.h", "proximityadaptorplugin_8h.html", [
      [ "ProximityAdaptorPlugin", "classProximityAdaptorPlugin.html", null ]
    ] ]
];