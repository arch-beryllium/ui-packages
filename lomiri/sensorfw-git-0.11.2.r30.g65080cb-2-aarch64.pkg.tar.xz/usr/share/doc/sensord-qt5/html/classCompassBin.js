var classCompassBin =
[
    [ "CompassBin", "classCompassBin.html#acca8991ea588b66dc2bd38932b2b389e", null ],
    [ "~CompassBin", "classCompassBin.html#a61e14e3f2f26769ed8608c399e4c64d3", null ]
];