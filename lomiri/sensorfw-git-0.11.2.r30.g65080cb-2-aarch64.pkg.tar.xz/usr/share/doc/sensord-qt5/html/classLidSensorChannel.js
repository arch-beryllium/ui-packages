var classLidSensorChannel =
[
    [ "LidSensorChannel", "classLidSensorChannel.html#a10554767ed224b754663655f789c601d", null ],
    [ "~LidSensorChannel", "classLidSensorChannel.html#a69450a113d522ad66691844c42c3c6c0", null ],
    [ "closed", "classLidSensorChannel.html#a3750e41efcac38d83d43af8e8cb45406", null ],
    [ "lidChanged", "classLidSensorChannel.html#a74a09fea2c9ef88562353a9a9bd6a038", null ],
    [ "start", "classLidSensorChannel.html#a64383831851f160bbe272bd5e7f19991", null ],
    [ "stop", "classLidSensorChannel.html#adcc9b081fabcdd036bff01b403fecc96", null ],
    [ "closed", "classLidSensorChannel.html#afe8b7b9484534ae2dc60eae65ddcd4a4", null ]
];