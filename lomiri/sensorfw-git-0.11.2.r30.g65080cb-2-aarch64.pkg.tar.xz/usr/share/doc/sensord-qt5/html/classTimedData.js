var classTimedData =
[
    [ "TimedData", "classTimedData.html#ac39ea73b8b0e8923b3b0fa93c42ae974", null ],
    [ "timestamp_", "classTimedData.html#a6eca8c497b18f436a0374bc8aafc575c", null ]
];