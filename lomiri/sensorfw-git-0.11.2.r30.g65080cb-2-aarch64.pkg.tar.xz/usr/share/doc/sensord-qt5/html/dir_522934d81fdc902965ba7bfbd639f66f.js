var dir_522934d81fdc902965ba7bfbd639f66f =
[
    [ "gyroscopeadaptor.h", "gyroscopeadaptor_8h.html", [
      [ "GyroscopeAdaptor", "classGyroscopeAdaptor.html", "classGyroscopeAdaptor" ]
    ] ],
    [ "gyroscopeadaptorplugin.h", "gyroscopeadaptorplugin_8h.html", [
      [ "GyroscopeAdaptorPlugin", "classGyroscopeAdaptorPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2gyroscopeadaptor_2moc__predefs_8h.html", "adaptors_2gyroscopeadaptor_2moc__predefs_8h" ]
];