var dir_7497d412c488235d5dc666fe658a84c4 =
[
    [ "moc_predefs.h", "adaptors_2oemtabletalsadaptor-ascii_2moc__predefs_8h.html", "adaptors_2oemtabletalsadaptor-ascii_2moc__predefs_8h" ],
    [ "oemtabletalsadaptor-ascii.h", "oemtabletalsadaptor-ascii_8h.html", [
      [ "OEMTabletALSAdaptorAscii", "classOEMTabletALSAdaptorAscii.html", "classOEMTabletALSAdaptorAscii" ]
    ] ],
    [ "oemtabletalsadaptor-asciiplugin.h", "oemtabletalsadaptor-asciiplugin_8h.html", [
      [ "OEMTabletALSAdaptorAsciiPlugin", "classOEMTabletALSAdaptorAsciiPlugin.html", null ]
    ] ]
];