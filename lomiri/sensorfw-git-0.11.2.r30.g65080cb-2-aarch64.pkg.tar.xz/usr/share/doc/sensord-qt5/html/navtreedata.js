/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "sensorfw", "index.html", [
    [ "Sensor Framework API documentation", "index.html", [
      [ "Introduction", "index.html#introsection", null ],
      [ "Sensorfw Developer Info", "index.html#devinfosection", [
        [ "Public API", "index.html#apisubsection", null ]
      ] ]
    ] ],
    [ "Dbus Interface", "dbusinterface.html", null ],
    [ "Developer Documentation", "developer.html", [
      [ "Sensor driver guideline", "developer.html#driverguide", null ],
      [ "Instructions For Writing Plug-ins for Sensor Framework", "developer.html#plugins", [
        [ "Plug-ins", "developer.html#pluginsubsection", [
          [ "Writing a Plug-in", "developer.html#writingpluginsub", null ]
        ] ],
        [ "Writing an Adaptor", "developer.html#writingadaptorsub", [
          [ "Interrupt based or busypoll", "developer.html#pollparagraph", null ],
          [ "Buffers", "developer.html#bufferparagraph", null ],
          [ "Reading data from driver", "developer.html#readingdataparagraph", null ],
          [ "Metadata", "developer.html#metadataparagraph", null ],
          [ "Implementing A Device Adaptor - the hardway", "developer.html#adaptorshardway", null ]
        ] ],
        [ "Writing a Filter", "developer.html#writingfilter", null ],
        [ "Writing a Sensor", "developer.html#writingsensorsection", null ],
        [ "Writing a Chain", "developer.html#writingchain", null ],
        [ "Metadata", "developer.html#metadatasubsection", null ],
        [ "Interval range(s)", "developer.html#rangesubsection", null ],
        [ "Data range(s)", "developer.html#datarangesubsection", null ],
        [ "Standby override", "developer.html#standbysubsection", null ],
        [ "Buffer size and interval", "developer.html#buffersubsection", null ]
      ] ],
      [ "Configuration Files", "developer.html#configurationsection", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Properties", "functions_prop.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"abstractsensor__i_8h.html",
"adaptors_2accelerometeradaptor_2moc__predefs_8h.html#a889943b266851fe7e9cdac86795507aa",
"adaptors_2alsadaptor-ascii_2moc__predefs_8h.html#a33433eca9e18e14156165252746f4d44",
"adaptors_2alsadaptor-ascii_2moc__predefs_8h.html#acb3a3a30075a9589b520df3b329df29e",
"adaptors_2alsadaptor-evdev_2moc__predefs_8h.html#a6a4d11835d03027f3929b84fe7b55bf6",
"adaptors_2alsadaptor-sysfs_2moc__predefs_8h.html#a0a3bd26d0b040f0781a238e4aedd3dbe",
"adaptors_2alsadaptor-sysfs_2moc__predefs_8h.html#aa193732f61f92fbcd9273d0f105c6566",
"adaptors_2alsadaptor_2moc__predefs_8h.html#a4e65214f450ef6326b96b52e6dd5714b",
"adaptors_2alsadaptor_2moc__predefs_8h.html#aeadf45b83bb46bb1d335f380896eb954",
"adaptors_2gyroscopeadaptor-evdev_2moc__predefs_8h.html#a7f18358ae5a65523140cb561bbeaa3a9",
"adaptors_2gyroscopeadaptor_2moc__predefs_8h.html#a287cbae3fb7eb2bdc8906729897524c9",
"adaptors_2gyroscopeadaptor_2moc__predefs_8h.html#ac15da069257627fefd71d875d538b73d",
"adaptors_2humidityadaptor_2moc__predefs_8h.html#a63882901a83ff1f3d832904b233b4e99",
"adaptors_2iioadaptor_2moc__predefs_8h.html#a02ee5c8ce8c3a0262b18d716cdeb2d1d",
"adaptors_2iioadaptor_2moc__predefs_8h.html#a97e13c059a63d2d547cc4a9f386641d2",
"adaptors_2kbslideradaptor_2moc__predefs_8h.html#a43c037cf54e7474a2be1d46c4f785fe9",
"adaptors_2kbslideradaptor_2moc__predefs_8h.html#adc1ccadf1d98117e586324ccb189c09f",
"adaptors_2lidsensoradaptor-evdev_2moc__predefs_8h.html#a775d1a831fa88d8c38c76d31947a8ebf",
"adaptors_2magnetometeradaptor-ascii_2moc__predefs_8h.html#a1c54273d3f148c51ad48fd738d1e6cbe",
"adaptors_2magnetometeradaptor-ascii_2moc__predefs_8h.html#ab572f59c4b0c5a1f4c2953f38a76d7b3",
"adaptors_2magnetometeradaptor-evdev_2moc__predefs_8h.html#a5db559b8fe7a2135f05686e92ce64d9d",
"adaptors_2magnetometeradaptor-evdev_2moc__predefs_8h.html#afa81a4f55615fe1ebd67afb0794b1980",
"adaptors_2magnetometeradaptor-ncdk_2moc__predefs_8h.html#a8f41f2e3963dd91abee2b29461361f02",
"adaptors_2magnetometeradaptor_2moc__predefs_8h.html#a3bc6597592a4ad7d7f73b673fbc7336a",
"adaptors_2magnetometeradaptor_2moc__predefs_8h.html#ad149c0565fcf669b23f483e5b7f80dbd",
"adaptors_2mpu6050accelerometer_2moc__predefs_8h.html#a70ffee09638ac75a263b1a2e5a473c85",
"adaptors_2mrstaccelerometer_2moc__predefs_8h.html#a158b9e85a96f0cf9698a6202071e8061",
"adaptors_2mrstaccelerometer_2moc__predefs_8h.html#aa9e067f885a7396c1427d1547a89e063",
"adaptors_2oaktrailaccelerometer_2moc__predefs_8h.html#a54983bc256dc296a42fe88b9be24f268",
"adaptors_2oaktrailaccelerometer_2moc__predefs_8h.html#af1506af1d41c2238fd4d09e4fd255758",
"adaptors_2oemtabletaccelerometer_2moc__predefs_8h.html#a86bb5059d696b19082c1aff4ae93a87a",
"adaptors_2oemtabletalsadaptor-ascii_2moc__predefs_8h.html#a300c6970bb64b04e45a9c2ed139ecce8",
"adaptors_2oemtabletalsadaptor-ascii_2moc__predefs_8h.html#ac7bbc3e28627fae341e79687b733101b",
"adaptors_2pegatronaccelerometeradaptor_2moc__predefs_8h.html#a68e0683c8f359f7d7e013706fbcc2040",
"adaptors_2pressureadaptor_2moc__predefs_8h.html#a08d4062230ffc8494f4be4f6447497e4",
"adaptors_2pressureadaptor_2moc__predefs_8h.html#a9f8e418d5a6f916ffe36f250fb99d7bc",
"adaptors_2proximityadaptor-ascii_2moc__predefs_8h.html#a4ca36196b9f45fa67a0b23c43c658aa1",
"adaptors_2proximityadaptor-ascii_2moc__predefs_8h.html#ae9a1914a564951612704f3f6630663f3",
"adaptors_2proximityadaptor-evdev_2moc__predefs_8h.html#a7b63d9780e8127a88ad9554ff35e0a01",
"adaptors_2proximityadaptor_2moc__predefs_8h.html#a279ff83df60f2c8ff459cda12dfad97d",
"adaptors_2proximityadaptor_2moc__predefs_8h.html#abf681096fa9e21512a3fe83f0dcfdb36",
"adaptors_2steaccelerometeradaptor_2moc__predefs_8h.html#a6310789290c9c5717826b56443ce69ec",
"adaptors_2tapadaptor_2moc__predefs_8h.html#a01763e0801406de2e88b94f4ad1298de",
"adaptors_2tapadaptor_2moc__predefs_8h.html#a967b4ada96d28b97bc07e26e1def8e66",
"adaptors_2temperatureadaptor_2moc__predefs_8h.html#a40a928fa8e7268a4fae33ef19af44f2f",
"adaptors_2temperatureadaptor_2moc__predefs_8h.html#ad7a5615aea1516ee885112456cf695e8",
"adaptors_2touchadaptor_2moc__predefs_8h.html#a76363f8817bf3df4542ebbcce172df53",
"chains_2accelerometerchain_2moc__predefs_8h.html#a02ee5c8ce8c3a0262b18d716cdeb2d1d",
"chains_2accelerometerchain_2moc__predefs_8h.html#a97e13c059a63d2d547cc4a9f386641d2",
"chains_2compasschain_2moc__predefs_8h.html#a43c037cf54e7474a2be1d46c4f785fe9",
"chains_2compasschain_2moc__predefs_8h.html#adc1ccadf1d98117e586324ccb189c09f",
"chains_2magcalibrationchain_2moc__predefs_8h.html#a775d1a831fa88d8c38c76d31947a8ebf",
"chains_2orientationchain_2moc__predefs_8h.html#a1c54273d3f148c51ad48fd738d1e6cbe",
"chains_2orientationchain_2moc__predefs_8h.html#ab572f59c4b0c5a1f4c2953f38a76d7b3",
"classAccelerometerSensorChannelAdaptor.html#ad25dc30128870c01d22d2d951c38fde5",
"classHybrisOrientationAdaptor.html#a4e5fba7846e5b8339172058c747fb400",
"classOrientation.html#a16ff6b90d0266bddb604eeb70ae8c384a0af986f909b54700634e0a9cf78b138a",
"classStabilityFilter.html#a7321da5bdf03c9eb8c195b4900862ad1",
"datatypes_2moc__predefs_8h.html#a10a15ae17c3b791fe9b9721965ebfee4",
"datatypes_2moc__predefs_8h.html#aa5be39d362c571d48d6236f0bd58f1fc",
"filters_2avgaccfilter_2moc__predefs_8h.html#a0958474253d23ca2c87e817c16f74eda",
"filters_2avgaccfilter_2moc__predefs_8h.html#aa092b0d4c1d4d4407b97024f6cb2820c",
"filters_2coordinatealignfilter_2moc__predefs_8h.html#a4d78dd41059205e8fd1a29af6dda266c",
"filters_2coordinatealignfilter_2moc__predefs_8h.html#ae9ed936cc90c092e15526478bdbbefe0",
"filters_2declinationfilter_2moc__predefs_8h.html#a7df1cb434b3b8baae4bf6053cb2a3a4a",
"filters_2downsamplefilter_2moc__predefs_8h.html#a280f0a9058cc03c2dac890a19881b1fb",
"filters_2downsamplefilter_2moc__predefs_8h.html#ac0fe3e739d0b847c07dde20eabf2ab3d",
"filters_2magcoordinatealignfilter_2moc__predefs_8h.html#a633c8309a126fc7c098e83c3dcb2ea5d",
"filters_2orientationinterpreter_2moc__predefs_8h.html#a01d0061df498c537ecd56d53f1130082",
"filters_2orientationinterpreter_2moc__predefs_8h.html#a96b511bfa61e4203ec3668fb39063309",
"filters_2rotationfilter_2moc__predefs_8h.html#a42c04530cde3529000b65eab84d6ef6b",
"filters_2rotationfilter_2moc__predefs_8h.html#ada3957596c2e4bce8eac43e196c75053",
"magneticfield_8h.html",
"qt-api_2moc__predefs_8h.html#a43b043e9a6f2bd06da6322e5dee17c74",
"qt-api_2moc__predefs_8h.html#adb0d09cff489746c5456407aa832fced",
"sensord_2moc__predefs_8h.html#a6f2032bd7e6248b526a2c13e37c7b972",
"sensors_2accelerometersensor_2moc__predefs_8h.html#a0db94af36817ff65de3c4cbcbae42301",
"sensors_2accelerometersensor_2moc__predefs_8h.html#aa3f186f612efe5edfcc371c95617f06f",
"sensors_2alssensor_2moc__predefs_8h.html#a4f69990d03f9fb0c390a6fbad28a737b",
"sensors_2alssensor_2moc__predefs_8h.html#aeb56455e98000942147dfd63ec1c2fa6",
"sensors_2compasssensor_2moc__predefs_8h.html#a8394afe92148ddbdf0e0697978cd1382",
"sensors_2gyroscopesensor_2moc__predefs_8h.html#a2b695357ce4b46971d54e8e9dfe5724f",
"sensors_2gyroscopesensor_2moc__predefs_8h.html#ac3cd8b035cfb8a68f6d1119ace36f1cc",
"sensors_2humiditysensor_2moc__predefs_8h.html#a65967d857259eb36c9546a512f2ab4b5",
"sensors_2lidsensor_2moc__predefs_8h.html#a059c92544effeec0d7fac0fd1f14e697",
"sensors_2lidsensor_2moc__predefs_8h.html#a9a8a7cd9484baf4b72ab15682745d119",
"sensors_2magnetometersensor_2moc__predefs_8h.html#a4a20b2c078ee12e2be450e83e5dacc9d",
"sensors_2magnetometersensor_2moc__predefs_8h.html#ae19860f43757eb1fc151b38cb3bbc278",
"sensors_2orientationsensor_2moc__predefs_8h.html#a78ed6a6fd2aa3ae6c665c7f8b4b6797e",
"sensors_2pressuresensor_2moc__predefs_8h.html#a213133a8dca206becf88c2e3523b124a",
"sensors_2pressuresensor_2moc__predefs_8h.html#ab86380373ae9fa385c8a2464023774a8",
"sensors_2proximitysensor_2moc__predefs_8h.html#a5f5ce266e768d95b9fd04856e5826aff",
"sensors_2proximitysensor_2moc__predefs_8h.html#afc45bfe4241907d615bb96ed6f4fd142",
"sensors_2rotationsensor_2moc__predefs_8h.html#a9100cdbe1fc4c179ace205e0dbe7befd",
"sensors_2stepcountersensor_2moc__predefs_8h.html#a3dda013c532cea311e9a22bf90dcec86",
"sensors_2stepcountersensor_2moc__predefs_8h.html#ad3062ff83239e8dd2b8969a2f368d608",
"sensors_2tapsensor_2moc__predefs_8h.html#a72e3c30a05bd2bb63d76550e451a438e",
"sensors_2temperaturesensor_2moc__predefs_8h.html#a17f94731962876cdac979ae093f52605",
"sensors_2temperaturesensor_2moc__predefs_8h.html#aad2e8f7e8d06ab966a1210f4a7d65770"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';