var dir_d7c06e8cb0cd7f904a46c6051db57eed =
[
    [ "avgaccfilter.h", "avgaccfilter_8h.html", [
      [ "AvgAccFilter", "classAvgAccFilter.html", "classAvgAccFilter" ]
    ] ],
    [ "avgaccfilterplugin.h", "avgaccfilterplugin_8h.html", [
      [ "AvgAccFilterPlugin", "classAvgAccFilterPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "filters_2avgaccfilter_2moc__predefs_8h.html", "filters_2avgaccfilter_2moc__predefs_8h" ]
];