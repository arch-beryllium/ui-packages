var classDownsampleFilter =
[
    [ "DownsampleFilter", "classDownsampleFilter.html#ac8ae0cb33cd1bc615c87a8e667ba52a1", null ],
    [ "bufferSize", "classDownsampleFilter.html#a6f31882fe46b6a15d54e8e4503e6ce48", null ],
    [ "setBufferSize", "classDownsampleFilter.html#a8159f7c3260791ff426294000e574aaa", null ],
    [ "setTimeout", "classDownsampleFilter.html#a65d4b3098b2cd9d271b84ff9afb99bba", null ],
    [ "timeout", "classDownsampleFilter.html#a0fc2c2ff09b9cff959b3a7c34ee4880c", null ],
    [ "bufferSize", "classDownsampleFilter.html#a9bf18389deb207428e869d5ef49db4b7", null ],
    [ "timeout", "classDownsampleFilter.html#a5ced08b08066f90b8e26260caaec49f8", null ]
];