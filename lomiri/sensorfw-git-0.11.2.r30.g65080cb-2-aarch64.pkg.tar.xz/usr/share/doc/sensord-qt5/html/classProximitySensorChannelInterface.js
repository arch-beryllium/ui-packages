var classProximitySensorChannelInterface =
[
    [ "ProximitySensorChannelInterface", "classProximitySensorChannelInterface.html#af57550da626c1adf90087fb65133f293", null ],
    [ "dataAvailable", "classProximitySensorChannelInterface.html#a8441242db106fc7358cf38b4581c77e7", null ],
    [ "dataReceivedImpl", "classProximitySensorChannelInterface.html#ae235b87fce71c5256ab9f643a1f0fe7d", null ],
    [ "proximity", "classProximitySensorChannelInterface.html#a8e61338f1d78c6b9743049953a86f986", null ],
    [ "proximityReflectance", "classProximitySensorChannelInterface.html#acbfaf0d624bf5fc9919e8968203e0525", null ],
    [ "reflectanceDataAvailable", "classProximitySensorChannelInterface.html#aa1842015570e9178d0cd809a04e88fd0", null ],
    [ "proximity", "classProximitySensorChannelInterface.html#acbf03af79b59376ee71169b3d71395af", null ],
    [ "proximityReflectance", "classProximitySensorChannelInterface.html#a445021b1f58532df251ea98be134b810", null ]
];