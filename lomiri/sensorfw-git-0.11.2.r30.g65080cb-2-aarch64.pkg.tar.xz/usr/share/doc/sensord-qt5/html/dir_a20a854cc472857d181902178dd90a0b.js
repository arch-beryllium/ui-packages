var dir_a20a854cc472857d181902178dd90a0b =
[
    [ "moc_predefs.h", "sensors_2pressuresensor_2moc__predefs_8h.html", "sensors_2pressuresensor_2moc__predefs_8h" ],
    [ "pressureplugin.h", "pressureplugin_8h.html", [
      [ "PressurePlugin", "classPressurePlugin.html", null ]
    ] ],
    [ "pressuresensor.h", "pressuresensor_8h.html", [
      [ "PressureSensorChannel", "classPressureSensorChannel.html", "classPressureSensorChannel" ]
    ] ],
    [ "pressuresensor_a.h", "pressuresensor__a_8h.html", [
      [ "PressureSensorChannelAdaptor", "classPressureSensorChannelAdaptor.html", "classPressureSensorChannelAdaptor" ]
    ] ]
];