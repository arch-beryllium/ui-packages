var classAvgVarFilter =
[
    [ "AvgVarFilter", "classAvgVarFilter.html#a332dd62b4dab1eb8ded424aea7a717a5", null ],
    [ "reset", "classAvgVarFilter.html#a3de84bb46176abca495194fd4934738c", null ]
];