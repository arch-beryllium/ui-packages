var dir_7778eb3ec95a454f2f667296c3c15b64 =
[
    [ "moc_predefs.h", "sensors_2orientationsensor_2moc__predefs_8h.html", "sensors_2orientationsensor_2moc__predefs_8h" ],
    [ "orientationplugin.h", "orientationplugin_8h.html", [
      [ "OrientationPlugin", "classOrientationPlugin.html", null ]
    ] ],
    [ "orientationsensor.h", "orientationsensor_8h.html", [
      [ "OrientationSensorChannel", "classOrientationSensorChannel.html", "classOrientationSensorChannel" ]
    ] ],
    [ "orientationsensor_a.h", "orientationsensor__a_8h.html", [
      [ "OrientationSensorChannelAdaptor", "classOrientationSensorChannelAdaptor.html", "classOrientationSensorChannelAdaptor" ]
    ] ]
];