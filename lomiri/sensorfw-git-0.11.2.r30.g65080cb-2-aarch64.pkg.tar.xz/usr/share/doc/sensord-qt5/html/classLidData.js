var classLidData =
[
    [ "Type", "classLidData.html#a6dc577638cac3d5f6f7dc16a7b67c0d2", [
      [ "UnknownLid", "classLidData.html#a6dc577638cac3d5f6f7dc16a7b67c0d2a0b103fb2ca35f0bf03d84f2271b113f3", null ],
      [ "FrontLid", "classLidData.html#a6dc577638cac3d5f6f7dc16a7b67c0d2ab9ed0b34d187aa95ba2777a0ae2f0964", null ],
      [ "BackLid", "classLidData.html#a6dc577638cac3d5f6f7dc16a7b67c0d2a5eeb6b6d4878434bf7da3a1afd526c68", null ]
    ] ],
    [ "LidData", "classLidData.html#a443f4893c9d802ae46a50fe99041978f", null ],
    [ "LidData", "classLidData.html#acea1a2ac70601624ff916dc4a3b27b41", null ],
    [ "type_", "classLidData.html#a7f34a089b7d86f02ff607dfa9f2484ea", null ],
    [ "value_", "classLidData.html#aedf5f9fca5696ef558324b119e5064d8", null ]
];