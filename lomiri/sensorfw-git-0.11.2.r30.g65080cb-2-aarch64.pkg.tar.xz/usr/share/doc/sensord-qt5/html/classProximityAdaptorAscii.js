var classProximityAdaptorAscii =
[
    [ "ProximityAdaptorAscii", "classProximityAdaptorAscii.html#ac751f60397d74d6bdd8ac3135a9bc0c0", null ],
    [ "~ProximityAdaptorAscii", "classProximityAdaptorAscii.html#a8a294d6d9241ad6832afcb84aa35b488", null ]
];