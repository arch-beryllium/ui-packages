var namespaces_dup =
[
    [ "local", "namespacelocal.html", null ]
];