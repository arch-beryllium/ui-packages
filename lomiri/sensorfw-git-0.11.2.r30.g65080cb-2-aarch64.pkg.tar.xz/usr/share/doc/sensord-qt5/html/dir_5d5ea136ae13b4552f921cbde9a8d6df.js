var dir_5d5ea136ae13b4552f921cbde9a8d6df =
[
    [ "accelerometeradaptor.h", "accelerometeradaptor_8h.html", [
      [ "AccelerometerAdaptor", "classAccelerometerAdaptor.html", "classAccelerometerAdaptor" ]
    ] ],
    [ "accelerometeradaptorplugin.h", "accelerometeradaptorplugin_8h.html", [
      [ "AccelerometerAdaptorPlugin", "classAccelerometerAdaptorPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2accelerometeradaptor_2moc__predefs_8h.html", "adaptors_2accelerometeradaptor_2moc__predefs_8h" ]
];