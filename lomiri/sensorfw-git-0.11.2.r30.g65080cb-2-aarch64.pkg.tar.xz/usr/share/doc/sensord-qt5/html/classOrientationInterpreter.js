var classOrientationInterpreter =
[
    [ "orientation", "classOrientationInterpreter.html#a68ede01d09e8b35cc09b83cf959741e1", null ],
    [ "orientation", "classOrientationInterpreter.html#a02aacf119b3f451f6b3ec3800e813ac8", null ]
];