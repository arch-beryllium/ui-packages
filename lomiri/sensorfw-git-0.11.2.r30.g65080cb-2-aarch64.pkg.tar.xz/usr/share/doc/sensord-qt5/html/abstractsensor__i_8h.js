var abstractsensor__i_8h =
[
    [ "AbstractSensorChannelInterface", "classAbstractSensorChannelInterface.html", "classAbstractSensorChannelInterface" ],
    [ "AbstractSensor", "abstractsensor__i_8h.html#afae05b99005a00f51b28324fc6f5fab6", null ]
];