var classTouchData =
[
    [ "FingerState", "classTouchData.html#aadf5be4645c528a7156651e2b1589d3d", [
      [ "FingerStateNotPresent", "classTouchData.html#aadf5be4645c528a7156651e2b1589d3da8622c8fc73d3f6db60c2c607c3190ceb", null ],
      [ "FingerStateAccurate", "classTouchData.html#aadf5be4645c528a7156651e2b1589d3daa5c790d2eb80aaa73e3cb4763294b547", null ],
      [ "FingerStateInaccurate", "classTouchData.html#aadf5be4645c528a7156651e2b1589d3dac3696455053024c7e3479da1766c2ad4", null ]
    ] ],
    [ "TouchData", "classTouchData.html#a6e19fb6c13e094fcb94375810b09277a", null ],
    [ "TouchData", "classTouchData.html#a0cf63d6f69bca32223390486bb271816", null ],
    [ "object_", "classTouchData.html#ae41827250d34b827cf9af9d265904145", null ],
    [ "state_", "classTouchData.html#a73631c5405dcc6d43de17b1ed6e3c3cf", null ]
];