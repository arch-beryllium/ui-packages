var dir_2c648fe0f36e0d6e03f4646fea4a3a47 =
[
    [ "avgvarfilter.h", "avgvarfilter_8h.html", [
      [ "AvgVarFilter", "classAvgVarFilter.html", "classAvgVarFilter" ]
    ] ],
    [ "compassbin.h", "compassbin_8h.html", [
      [ "CompassBin", "classCompassBin.html", "classCompassBin" ]
    ] ],
    [ "contextplugin.h", "contextplugin_8h.html", [
      [ "ContextPlugin", "classContextPlugin.html", null ]
    ] ],
    [ "contextsensor.h", "contextsensor_8h.html", [
      [ "ContextSensorChannel", "classContextSensorChannel.html", "classContextSensorChannel" ]
    ] ],
    [ "cutterfilter.h", "cutterfilter_8h.html", [
      [ "CutterFilter", "classCutterFilter.html", "classCutterFilter" ]
    ] ],
    [ "headingfilter.h", "headingfilter_8h.html", [
      [ "HeadingFilter", "classHeadingFilter.html", "classHeadingFilter" ]
    ] ],
    [ "normalizerfilter.h", "normalizerfilter_8h.html", [
      [ "NormalizerFilter", "classNormalizerFilter.html", "classNormalizerFilter" ]
    ] ],
    [ "orientationbin.h", "orientationbin_8h.html", [
      [ "OrientationBin", "classOrientationBin.html", "classOrientationBin" ]
    ] ],
    [ "screeninterpreterfilter.h", "screeninterpreterfilter_8h.html", [
      [ "ScreenInterpreterFilter", "classScreenInterpreterFilter.html", "classScreenInterpreterFilter" ]
    ] ],
    [ "stabilitybin.h", "stabilitybin_8h.html", [
      [ "StabilityBin", "classStabilityBin.html", "classStabilityBin" ]
    ] ],
    [ "stabilityfilter.h", "stabilityfilter_8h.html", [
      [ "StabilityFilter", "classStabilityFilter.html", "classStabilityFilter" ]
    ] ]
];