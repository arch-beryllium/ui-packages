var classProximityAdaptorEvdev =
[
    [ "ProximityState", "classProximityAdaptorEvdev.html#a66562d62b8aa372ad1ed5c85a956ae4b", [
      [ "ProximityStateUnknown", "classProximityAdaptorEvdev.html#a66562d62b8aa372ad1ed5c85a956ae4bae519494f7114f7da2158d0c096b1b305", null ],
      [ "ProximityStateOpen", "classProximityAdaptorEvdev.html#a66562d62b8aa372ad1ed5c85a956ae4ba4e880416d93afe1a149a49d0c305e442", null ],
      [ "ProximityStateClosed", "classProximityAdaptorEvdev.html#a66562d62b8aa372ad1ed5c85a956ae4baec5d6c20947cc1a91f5138b31889ec04", null ]
    ] ],
    [ "ProximityAdaptorEvdev", "classProximityAdaptorEvdev.html#a93b0cc95a8f68f5ac330c6989a51075d", null ],
    [ "~ProximityAdaptorEvdev", "classProximityAdaptorEvdev.html#a5a8ee44ab24693c5b6aa630582b35428", null ],
    [ "resume", "classProximityAdaptorEvdev.html#a0f0d193e3e853f2a0f22016e6277e8cd", null ],
    [ "standby", "classProximityAdaptorEvdev.html#a730c5f446f899347b914ee3b4857efd9", null ],
    [ "startSensor", "classProximityAdaptorEvdev.html#a79e7d7fef201d872d7a4599efea86d5b", null ],
    [ "stopSensor", "classProximityAdaptorEvdev.html#ac01a2b0ff58fba9698e71c4eb6b78280", null ]
];