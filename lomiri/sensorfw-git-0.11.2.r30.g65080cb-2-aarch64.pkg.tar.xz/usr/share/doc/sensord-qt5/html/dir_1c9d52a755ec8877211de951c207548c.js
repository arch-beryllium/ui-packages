var dir_1c9d52a755ec8877211de951c207548c =
[
    [ "moc_predefs.h", "adaptors_2touchadaptor_2moc__predefs_8h.html", "adaptors_2touchadaptor_2moc__predefs_8h" ],
    [ "touchadaptor.h", "touchadaptor_8h.html", [
      [ "TouchAdaptor", "classTouchAdaptor.html", "classTouchAdaptor" ]
    ] ],
    [ "touchadaptorplugin.h", "touchadaptorplugin_8h.html", [
      [ "TouchAdaptorPlugin", "classTouchAdaptorPlugin.html", null ]
    ] ]
];