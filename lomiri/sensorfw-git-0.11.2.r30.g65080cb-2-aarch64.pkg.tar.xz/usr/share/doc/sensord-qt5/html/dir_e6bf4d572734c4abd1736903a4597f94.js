var dir_e6bf4d572734c4abd1736903a4597f94 =
[
    [ "declinationfilter.h", "declinationfilter_8h.html", [
      [ "DeclinationFilter", "classDeclinationFilter.html", "classDeclinationFilter" ]
    ] ],
    [ "declinationfilterplugin.h", "declinationfilterplugin_8h.html", [
      [ "DeclinationFilterPlugin", "classDeclinationFilterPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "filters_2declinationfilter_2moc__predefs_8h.html", "filters_2declinationfilter_2moc__predefs_8h" ]
];