var gyroscopesensor__i_8h =
[
    [ "GyroscopeSensorChannelInterface", "classGyroscopeSensorChannelInterface.html", "classGyroscopeSensorChannelInterface" ],
    [ "GyroscopeSensor", "gyroscopesensor__i_8h.html#a81bffb452a959855cdbf7174586faff8", null ]
];