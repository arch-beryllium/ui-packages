var dir_8a6a99e087d385c01360701a9f71089d =
[
    [ "alsadaptor-ascii.h", "alsadaptor-ascii_8h.html", [
      [ "ALSAdaptorAscii", "classALSAdaptorAscii.html", "classALSAdaptorAscii" ]
    ] ],
    [ "alsadaptor-asciiplugin.h", "alsadaptor-asciiplugin_8h.html", [
      [ "ALSAdaptorAsciiPlugin", "classALSAdaptorAsciiPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2alsadaptor-ascii_2moc__predefs_8h.html", "adaptors_2alsadaptor-ascii_2moc__predefs_8h" ]
];