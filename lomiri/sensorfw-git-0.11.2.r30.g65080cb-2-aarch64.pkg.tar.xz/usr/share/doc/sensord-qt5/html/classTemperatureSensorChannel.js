var classTemperatureSensorChannel =
[
    [ "TemperatureSensorChannel", "classTemperatureSensorChannel.html#a5d7828829c3242b8cec6fd496c11043b", null ],
    [ "~TemperatureSensorChannel", "classTemperatureSensorChannel.html#a8f12d292450815138694c21e4cb67b7a", null ],
    [ "start", "classTemperatureSensorChannel.html#a16884447083ca2a221399c11166f6c6a", null ],
    [ "stop", "classTemperatureSensorChannel.html#ae0e1c50bd902444f81efea8c4af5a969", null ],
    [ "temperature", "classTemperatureSensorChannel.html#a3ffd4a817d3cb8ef2a2464bd4677220d", null ],
    [ "temperatureChanged", "classTemperatureSensorChannel.html#a53631e8f5c716a744710bb88c0b8da4a", null ],
    [ "temperature", "classTemperatureSensorChannel.html#a419638d9ce4ca0b74f8b355943ef8cd9", null ]
];