var classTemperatureSensorChannelInterface =
[
    [ "TemperatureSensorChannelInterface", "classTemperatureSensorChannelInterface.html#afbb70c9cac0d89185da6916311981802", null ],
    [ "dataReceivedImpl", "classTemperatureSensorChannelInterface.html#a1eb5b6f7f04163b14fa66623df933fea", null ],
    [ "temperature", "classTemperatureSensorChannelInterface.html#a55b8e8da1edefa0150fac7d611fd6756", null ],
    [ "temperatureChanged", "classTemperatureSensorChannelInterface.html#a18cdec118bc629626f701ca58b10d4f7", null ],
    [ "temperature", "classTemperatureSensorChannelInterface.html#a8a0dc9e6934c273a6300b0643fbc0639", null ]
];