var classPressureAdaptor =
[
    [ "PressureAdaptor", "classPressureAdaptor.html#a57103ccce1776f29f301566638941af6", null ],
    [ "~PressureAdaptor", "classPressureAdaptor.html#a4a0294f5869f1d495ea61184041f9a9e", null ],
    [ "evaluateIntervalRequests", "classPressureAdaptor.html#a9a67ecb88eba9a3b44b478e2951cf08d", null ],
    [ "resume", "classPressureAdaptor.html#a323e720199dffcf4c8c20d9f862d4a49", null ],
    [ "standby", "classPressureAdaptor.html#a062aadfab13847d36799e3e898291c7e", null ],
    [ "startSensor", "classPressureAdaptor.html#a16aa5dcaf741438128f22a377ecfb5de", null ],
    [ "stopSensor", "classPressureAdaptor.html#a2d10a40659ab35555edcba711aad8655", null ]
];