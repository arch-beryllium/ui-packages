var dir_c77a8e2546a9c75bbba96be2ef542c8e =
[
    [ "accelerometersensor", "dir_23c6fc9a7fa0f4cfb53d3bf9631e6883.html", "dir_23c6fc9a7fa0f4cfb53d3bf9631e6883" ],
    [ "alssensor", "dir_d6c492f8e755bc1fd07d44cfad64b504.html", "dir_d6c492f8e755bc1fd07d44cfad64b504" ],
    [ "compasssensor", "dir_93448298e7c82156676dbd00cf8aacad.html", "dir_93448298e7c82156676dbd00cf8aacad" ],
    [ "contextplugin", "dir_2c648fe0f36e0d6e03f4646fea4a3a47.html", "dir_2c648fe0f36e0d6e03f4646fea4a3a47" ],
    [ "gyroscopesensor", "dir_989d2d56456060f06abf34e729ba37ed.html", "dir_989d2d56456060f06abf34e729ba37ed" ],
    [ "humiditysensor", "dir_1391fcdf19110c78c729dcf7aa46956a.html", "dir_1391fcdf19110c78c729dcf7aa46956a" ],
    [ "lidsensor", "dir_28993b946299ddd1a1a95440a7c58a3d.html", "dir_28993b946299ddd1a1a95440a7c58a3d" ],
    [ "magnetometersensor", "dir_055b8aed8e2ff52f4da5d2103f48322d.html", "dir_055b8aed8e2ff52f4da5d2103f48322d" ],
    [ "orientationsensor", "dir_7778eb3ec95a454f2f667296c3c15b64.html", "dir_7778eb3ec95a454f2f667296c3c15b64" ],
    [ "pressuresensor", "dir_a20a854cc472857d181902178dd90a0b.html", "dir_a20a854cc472857d181902178dd90a0b" ],
    [ "proximitysensor", "dir_664c2f483ef501a3d6e4e7f4ab327da2.html", "dir_664c2f483ef501a3d6e4e7f4ab327da2" ],
    [ "rotationsensor", "dir_12a06c996aefa9003ffffca3392a1b43.html", "dir_12a06c996aefa9003ffffca3392a1b43" ],
    [ "stepcountersensor", "dir_3581c6d1ef8661f0a0dba97eaa02c336.html", "dir_3581c6d1ef8661f0a0dba97eaa02c336" ],
    [ "tapsensor", "dir_2971b7f94ec909d55f793c86ffe61455.html", "dir_2971b7f94ec909d55f793c86ffe61455" ],
    [ "temperaturesensor", "dir_d63bee19bdb9552062e403a8525de23f.html", "dir_d63bee19bdb9552062e403a8525de23f" ]
];