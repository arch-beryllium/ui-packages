var dir_93448298e7c82156676dbd00cf8aacad =
[
    [ "compassplugin.h", "compassplugin_8h.html", [
      [ "CompassPlugin", "classCompassPlugin.html", null ]
    ] ],
    [ "compasssensor.h", "compasssensor_8h.html", [
      [ "CompassSensorChannel", "classCompassSensorChannel.html", "classCompassSensorChannel" ]
    ] ],
    [ "compasssensor_a.h", "compasssensor__a_8h.html", [
      [ "CompassSensorChannelAdaptor", "classCompassSensorChannelAdaptor.html", "classCompassSensorChannelAdaptor" ]
    ] ],
    [ "moc_predefs.h", "sensors_2compasssensor_2moc__predefs_8h.html", "sensors_2compasssensor_2moc__predefs_8h" ]
];