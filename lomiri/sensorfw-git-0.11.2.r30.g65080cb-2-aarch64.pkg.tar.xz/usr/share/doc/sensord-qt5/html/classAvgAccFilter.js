var classAvgAccFilter =
[
    [ "factor", "classAvgAccFilter.html#a72d78b66de4f2b27d3afc288b2f590cc", null ],
    [ "reset", "classAvgAccFilter.html#a7b41d69cc64a3a0a0d37d2fc4db5b6dd", null ],
    [ "setFactor", "classAvgAccFilter.html#ab61277f12ffb4de8c2bf16ca7466916a", null ]
];