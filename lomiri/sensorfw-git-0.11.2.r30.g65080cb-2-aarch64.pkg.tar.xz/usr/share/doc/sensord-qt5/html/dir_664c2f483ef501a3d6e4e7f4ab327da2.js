var dir_664c2f483ef501a3d6e4e7f4ab327da2 =
[
    [ "moc_predefs.h", "sensors_2proximitysensor_2moc__predefs_8h.html", "sensors_2proximitysensor_2moc__predefs_8h" ],
    [ "proximityplugin.h", "proximityplugin_8h.html", [
      [ "ProximityPlugin", "classProximityPlugin.html", null ]
    ] ],
    [ "proximitysensor.h", "proximitysensor_8h.html", [
      [ "ProximitySensorChannel", "classProximitySensorChannel.html", "classProximitySensorChannel" ]
    ] ],
    [ "proximitysensor_a.h", "proximitysensor__a_8h.html", [
      [ "ProximitySensorChannelAdaptor", "classProximitySensorChannelAdaptor.html", "classProximitySensorChannelAdaptor" ]
    ] ]
];