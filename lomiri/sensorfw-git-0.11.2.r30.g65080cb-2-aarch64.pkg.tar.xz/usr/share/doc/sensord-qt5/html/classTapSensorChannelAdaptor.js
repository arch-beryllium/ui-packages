var classTapSensorChannelAdaptor =
[
    [ "TapSensorChannelAdaptor", "classTapSensorChannelAdaptor.html#a70fec5f8dd04932165632f971a14273a", null ],
    [ "dataAvailable", "classTapSensorChannelAdaptor.html#a392605939b6062886793321b77db557b", null ]
];