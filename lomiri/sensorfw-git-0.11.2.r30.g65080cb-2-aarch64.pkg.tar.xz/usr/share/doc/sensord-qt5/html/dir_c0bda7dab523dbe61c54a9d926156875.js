var dir_c0bda7dab523dbe61c54a9d926156875 =
[
    [ "lidsensoradaptor-evdev.h", "lidsensoradaptor-evdev_8h.html", [
      [ "LidSensorAdaptorEvdev", "classLidSensorAdaptorEvdev.html", "classLidSensorAdaptorEvdev" ]
    ] ],
    [ "lidsensoradaptor-evdevplugin.h", "lidsensoradaptor-evdevplugin_8h.html", [
      [ "LidsensorAdaptorEvdevPlugin", "classLidsensorAdaptorEvdevPlugin.html", null ]
    ] ],
    [ "moc_predefs.h", "adaptors_2lidsensoradaptor-evdev_2moc__predefs_8h.html", "adaptors_2lidsensoradaptor-evdev_2moc__predefs_8h" ]
];