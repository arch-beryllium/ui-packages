var classHybrisProximityAdaptor =
[
    [ "HybrisProximityAdaptor", "classHybrisProximityAdaptor.html#a683a9b2b5b3937ebc3159e729272bd36", null ],
    [ "~HybrisProximityAdaptor", "classHybrisProximityAdaptor.html#af7b5c56ba6374daa4611ba7683c95729", null ],
    [ "init", "classHybrisProximityAdaptor.html#ab08e1e31b0af61fa1c829ffde8919396", null ],
    [ "processSample", "classHybrisProximityAdaptor.html#a1305660f4ed0358e9b6916b0dccb6a7b", null ],
    [ "sendInitialData", "classHybrisProximityAdaptor.html#a01c198d3569ae8185939e88bf6546deb", null ],
    [ "startSensor", "classHybrisProximityAdaptor.html#aa745228c4b84c67017fa782d6e50ea5c", null ],
    [ "stopSensor", "classHybrisProximityAdaptor.html#a6645c517ec5f7b44b1bad2489c566932", null ]
];