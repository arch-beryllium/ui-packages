var classSocketReader =
[
    [ "SocketReader", "classSocketReader.html#a6bdc390e3fea3f878db47caed559a283", null ],
    [ "~SocketReader", "classSocketReader.html#a756c8b17c51c79a88df99f14d81be171", null ],
    [ "dropConnection", "classSocketReader.html#aac9e52f2ae0dc255373fcde5bf4523de", null ],
    [ "initiateConnection", "classSocketReader.html#ad5a4649b834ee4aa6b6995f6fa2b9820", null ],
    [ "isConnected", "classSocketReader.html#ad023ad75312205c5e40ed6ae4ba2d727", null ],
    [ "read", "classSocketReader.html#a4e3d1cdf828ee0aa98e0f5970b578ff3", null ],
    [ "read", "classSocketReader.html#aefd74292da362ebdc2dc2c91b65530c4", null ],
    [ "socket", "classSocketReader.html#a6cff9fb7dd5422db6edac57bb16d5a86", null ]
];