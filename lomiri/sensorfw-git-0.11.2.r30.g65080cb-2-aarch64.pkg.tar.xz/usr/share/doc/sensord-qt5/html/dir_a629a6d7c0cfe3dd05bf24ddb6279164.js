var dir_a629a6d7c0cfe3dd05bf24ddb6279164 =
[
    [ "moc_predefs.h", "filters_2rotationfilter_2moc__predefs_8h.html", "filters_2rotationfilter_2moc__predefs_8h" ],
    [ "rotationfilter.h", "rotationfilter_8h.html", [
      [ "RotationFilter", "classRotationFilter.html", null ]
    ] ],
    [ "rotationfilterplugin.h", "rotationfilterplugin_8h.html", [
      [ "RotationFilterPlugin", "classRotationFilterPlugin.html", null ]
    ] ]
];