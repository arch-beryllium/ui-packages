var magnetometersensor__i_8h =
[
    [ "MagnetometerSensorChannelInterface", "classMagnetometerSensorChannelInterface.html", "classMagnetometerSensorChannelInterface" ],
    [ "MagnetometerSensor", "magnetometersensor__i_8h.html#a17f92f0a35d4d0607e52fc8ec94ab02d", null ]
];