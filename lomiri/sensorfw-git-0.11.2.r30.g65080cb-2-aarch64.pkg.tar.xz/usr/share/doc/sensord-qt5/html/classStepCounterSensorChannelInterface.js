var classStepCounterSensorChannelInterface =
[
    [ "StepCounterSensorChannelInterface", "classStepCounterSensorChannelInterface.html#a0c2ef288d6df333155bb845149a55d2e", null ],
    [ "dataReceivedImpl", "classStepCounterSensorChannelInterface.html#a2dd60bcfe6e4851aa815c71d1d8e9eab", null ],
    [ "StepCounterChanged", "classStepCounterSensorChannelInterface.html#a7ea76b7208440a125fce1c0929a06acc", null ],
    [ "steps", "classStepCounterSensorChannelInterface.html#aacfbebee106d21341a30c97c164af98d", null ],
    [ "steps", "classStepCounterSensorChannelInterface.html#a186c0e785f5359db11cc1acf8e5641e4", null ]
];