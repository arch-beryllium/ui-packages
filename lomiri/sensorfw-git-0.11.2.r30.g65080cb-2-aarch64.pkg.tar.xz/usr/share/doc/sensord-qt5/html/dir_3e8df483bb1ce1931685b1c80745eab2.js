var dir_3e8df483bb1ce1931685b1c80745eab2 =
[
    [ "gyroadaptor-evdevplugin.h", "gyroadaptor-evdevplugin_8h.html", [
      [ "GyroAdaptorEvdevPlugin", "classGyroAdaptorEvdevPlugin.html", null ]
    ] ],
    [ "gyroevdevadaptor.h", "gyroevdevadaptor_8h.html", [
      [ "GyroAdaptorEvdev", "classGyroAdaptorEvdev.html", "classGyroAdaptorEvdev" ]
    ] ],
    [ "moc_predefs.h", "adaptors_2gyroscopeadaptor-evdev_2moc__predefs_8h.html", "adaptors_2gyroscopeadaptor-evdev_2moc__predefs_8h" ]
];