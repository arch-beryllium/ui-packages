var files_dup =
[
    [ "adaptors", "dir_dd334a9480b6cf91d90a1a4823794cd8.html", "dir_dd334a9480b6cf91d90a1a4823794cd8" ],
    [ "chains", "dir_3459307ed1e66cc1772c0cdcc171b559.html", "dir_3459307ed1e66cc1772c0cdcc171b559" ],
    [ "datatypes", "dir_3916de72b8b95e910c6a3b58752f61a8.html", "dir_3916de72b8b95e910c6a3b58752f61a8" ],
    [ "doc", "dir_e68e8157741866f444e17edd764ebbae.html", "dir_e68e8157741866f444e17edd764ebbae" ],
    [ "filters", "dir_44e6750c3ba91f897faed10628147690.html", "dir_44e6750c3ba91f897faed10628147690" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "qt-api", "dir_3ec8de81d31f211ae5bf0454c673bbbc.html", "dir_3ec8de81d31f211ae5bf0454c673bbbc" ],
    [ "sensord", "dir_ca42ccd6faa40ad90e7600aee333bfd5.html", "dir_ca42ccd6faa40ad90e7600aee333bfd5" ],
    [ "sensors", "dir_c77a8e2546a9c75bbba96be2ef542c8e.html", "dir_c77a8e2546a9c75bbba96be2ef542c8e" ]
];