var classALSSensorChannel =
[
    [ "ALSSensorChannel", "classALSSensorChannel.html#aedc28e80247360f15f676cc2fa398fb6", null ],
    [ "~ALSSensorChannel", "classALSSensorChannel.html#accb4c90bb1c43c1a2a3fcd7889abdcf0", null ],
    [ "ALSChanged", "classALSSensorChannel.html#af549d3d3d20d54b08d8d39cd3e9c1f9c", null ],
    [ "lux", "classALSSensorChannel.html#a11004b43ccac1ef632c07f08c96b5a55", null ],
    [ "start", "classALSSensorChannel.html#a397d0f661cac25e133737f71c0d84d1a", null ],
    [ "stop", "classALSSensorChannel.html#aa3e9b42192f1e49975c356de279237ef", null ],
    [ "lux", "classALSSensorChannel.html#a79bfe15015ae07ba397eab975620c340", null ]
];