var classTemperatureAdaptor =
[
    [ "TemperatureAdaptor", "classTemperatureAdaptor.html#a26b1bef928bd6957b42f15d4c7ea3583", null ],
    [ "~TemperatureAdaptor", "classTemperatureAdaptor.html#a6832afe40f981b20fa66e4cb143084a1", null ],
    [ "evaluateIntervalRequests", "classTemperatureAdaptor.html#a5f1072db8300169dd281a767e62c4f30", null ],
    [ "resume", "classTemperatureAdaptor.html#a515678b39705829cb0a5354520b32728", null ],
    [ "standby", "classTemperatureAdaptor.html#a09565eb700a5c32d5fa22e3e9a7f8b4c", null ],
    [ "startSensor", "classTemperatureAdaptor.html#a960c0363a38a3521855f2b6d66a6206d", null ],
    [ "stopSensor", "classTemperatureAdaptor.html#a834f29bcd9cdcacd9e317faecebf7bb8", null ]
];