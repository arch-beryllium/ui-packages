var classRotationSensorChannel =
[
    [ "RotationSensorChannel", "classRotationSensorChannel.html#a9c9c4c7cca2b6a93f0f2faf3d4febefc", null ],
    [ "~RotationSensorChannel", "classRotationSensorChannel.html#a8e641edeeb149a1dd1803a2be25a1094", null ],
    [ "dataAvailable", "classRotationSensorChannel.html#afd27364682c11cec01fc29c5a29aa768", null ],
    [ "downsamplingSupported", "classRotationSensorChannel.html#a7e5189191f0070d038bf64c902ccaca6", null ],
    [ "hasZ", "classRotationSensorChannel.html#a95a3b20bad5a261901a02f8692dbe65b", null ],
    [ "interval", "classRotationSensorChannel.html#acce772d7389ee01b602c8e70cd628206", null ],
    [ "removeSession", "classRotationSensorChannel.html#ad8bc5f679c254ec49862321613841199", null ],
    [ "rotation", "classRotationSensorChannel.html#a73b5ebf9022289ebed206045e73cbc20", null ],
    [ "setInterval", "classRotationSensorChannel.html#ac60ed7f33438c6f5a3ddd36e0bf5b2d0", null ],
    [ "start", "classRotationSensorChannel.html#a59990984eded01f9de3dc3b894b70807", null ],
    [ "stop", "classRotationSensorChannel.html#aba3e13e283f550c4c2e2c0f976d05a09", null ],
    [ "hasZ", "classRotationSensorChannel.html#a6ea4f980f5c2a8eaa0ad052150aa95e9", null ],
    [ "rotation", "classRotationSensorChannel.html#af8135af4f25ce2406be1d4e189892ae7", null ]
];