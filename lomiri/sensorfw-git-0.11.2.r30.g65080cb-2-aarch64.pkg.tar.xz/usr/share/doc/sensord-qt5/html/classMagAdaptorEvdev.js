var classMagAdaptorEvdev =
[
    [ "MagAdaptorEvdev", "classMagAdaptorEvdev.html#a2b75a4debdf1e931bff300f1f6dbf08c", null ],
    [ "~MagAdaptorEvdev", "classMagAdaptorEvdev.html#a19c7033931c52ba1322b9b29f4ac9be9", null ],
    [ "evaluateIntervalRequests", "classMagAdaptorEvdev.html#a66053cf125121da9cfb8f100ffab5128", null ],
    [ "resume", "classMagAdaptorEvdev.html#a4c9437c14ca3921378d6d79e10b34655", null ],
    [ "standby", "classMagAdaptorEvdev.html#a05536acc66c3b645001f0f3903cef903", null ],
    [ "startSensor", "classMagAdaptorEvdev.html#a66b098bb01042b728a3743881ffdd711", null ],
    [ "stopSensor", "classMagAdaptorEvdev.html#a78f144347928d6d5d22a8757078ca58a", null ]
];