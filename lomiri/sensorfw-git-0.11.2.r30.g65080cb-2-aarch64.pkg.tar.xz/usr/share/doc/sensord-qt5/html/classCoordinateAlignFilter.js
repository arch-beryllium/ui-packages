var classCoordinateAlignFilter =
[
    [ "CoordinateAlignFilter", "classCoordinateAlignFilter.html#ac8d2e7690aab706ab1f67308b6e39b05", null ],
    [ "matrix", "classCoordinateAlignFilter.html#af43476ff70721833d8725c8ace004ede", null ],
    [ "setMatrix", "classCoordinateAlignFilter.html#abcf8e1c61c672389125783cd8dc4e5e7", null ],
    [ "transMatrix", "classCoordinateAlignFilter.html#a13f0845d1c50ca8ebe05c49a7e2d23f9", null ]
];