var classProximity =
[
    [ "Proximity", "classProximity.html#a15dc826d5afc130edad3eb1ad9869ccc", null ],
    [ "Proximity", "classProximity.html#a91c989486dc872fade6f476b8c3559d3", null ],
    [ "Proximity", "classProximity.html#af96f7db5274a932ec4f65ffa7fd91a00", null ],
    [ "operator=", "classProximity.html#a4740f8b80a9bb7e952427c17f63ed99b", null ],
    [ "operator==", "classProximity.html#a9b9c50ee8c303eb4b082931cf615f4f9", null ],
    [ "proximityData", "classProximity.html#a0e22d19ea349f39a35a8475d81fb4ada", null ],
    [ "reflectance", "classProximity.html#a0d7a9622cc2e36e35a29ce0d8de06fbb", null ],
    [ "withinProximity", "classProximity.html#aaa2d02342db40f761deac8eefaef4a11", null ],
    [ "operator>>", "classProximity.html#a2bb735dfe82cee369d797aad02849fb5", null ],
    [ "reflectance", "classProximity.html#a855d3a2e3a4588dd4ce648bda8a4b0b3", null ],
    [ "withinProximity", "classProximity.html#ac038fb0b327de942895e8cefdf553960", null ]
];