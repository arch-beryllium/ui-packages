var dir_3581c6d1ef8661f0a0dba97eaa02c336 =
[
    [ "moc_predefs.h", "sensors_2stepcountersensor_2moc__predefs_8h.html", "sensors_2stepcountersensor_2moc__predefs_8h" ],
    [ "stepcounterplugin.h", "stepcounterplugin_8h.html", [
      [ "StepCounterPlugin", "classStepCounterPlugin.html", null ]
    ] ],
    [ "stepcountersensor.h", "stepcountersensor_8h.html", [
      [ "StepCounterSensorChannel", "classStepCounterSensorChannel.html", "classStepCounterSensorChannel" ]
    ] ],
    [ "stepcountersensor_a.h", "stepcountersensor__a_8h.html", [
      [ "StepCounterSensorChannelAdaptor", "classStepCounterSensorChannelAdaptor.html", "classStepCounterSensorChannelAdaptor" ]
    ] ]
];